/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 166.0, "series": [{"data": [[0.0, 1.0], [0.1, 1.0], [0.2, 1.0], [0.3, 2.0], [0.4, 2.0], [0.5, 2.0], [0.6, 2.0], [0.7, 2.0], [0.8, 2.0], [0.9, 2.0], [1.0, 2.0], [1.1, 2.0], [1.2, 2.0], [1.3, 2.0], [1.4, 2.0], [1.5, 2.0], [1.6, 2.0], [1.7, 2.0], [1.8, 2.0], [1.9, 2.0], [2.0, 2.0], [2.1, 2.0], [2.2, 2.0], [2.3, 2.0], [2.4, 2.0], [2.5, 2.0], [2.6, 2.0], [2.7, 2.0], [2.8, 3.0], [2.9, 3.0], [3.0, 3.0], [3.1, 3.0], [3.2, 3.0], [3.3, 3.0], [3.4, 3.0], [3.5, 3.0], [3.6, 3.0], [3.7, 3.0], [3.8, 3.0], [3.9, 3.0], [4.0, 3.0], [4.1, 3.0], [4.2, 3.0], [4.3, 3.0], [4.4, 3.0], [4.5, 3.0], [4.6, 3.0], [4.7, 3.0], [4.8, 3.0], [4.9, 3.0], [5.0, 3.0], [5.1, 3.0], [5.2, 3.0], [5.3, 3.0], [5.4, 3.0], [5.5, 3.0], [5.6, 3.0], [5.7, 3.0], [5.8, 3.0], [5.9, 3.0], [6.0, 3.0], [6.1, 3.0], [6.2, 4.0], [6.3, 4.0], [6.4, 4.0], [6.5, 4.0], [6.6, 4.0], [6.7, 4.0], [6.8, 4.0], [6.9, 4.0], [7.0, 4.0], [7.1, 4.0], [7.2, 4.0], [7.3, 4.0], [7.4, 4.0], [7.5, 4.0], [7.6, 4.0], [7.7, 4.0], [7.8, 4.0], [7.9, 4.0], [8.0, 4.0], [8.1, 4.0], [8.2, 4.0], [8.3, 4.0], [8.4, 4.0], [8.5, 4.0], [8.6, 4.0], [8.7, 4.0], [8.8, 4.0], [8.9, 5.0], [9.0, 5.0], [9.1, 5.0], [9.2, 5.0], [9.3, 5.0], [9.4, 5.0], [9.5, 5.0], [9.6, 5.0], [9.7, 5.0], [9.8, 5.0], [9.9, 5.0], [10.0, 5.0], [10.1, 5.0], [10.2, 5.0], [10.3, 5.0], [10.4, 5.0], [10.5, 5.0], [10.6, 5.0], [10.7, 5.0], [10.8, 5.0], [10.9, 5.0], [11.0, 5.0], [11.1, 5.0], [11.2, 6.0], [11.3, 6.0], [11.4, 6.0], [11.5, 6.0], [11.6, 6.0], [11.7, 6.0], [11.8, 6.0], [11.9, 6.0], [12.0, 6.0], [12.1, 6.0], [12.2, 6.0], [12.3, 6.0], [12.4, 6.0], [12.5, 6.0], [12.6, 6.0], [12.7, 6.0], [12.8, 6.0], [12.9, 6.0], [13.0, 6.0], [13.1, 6.0], [13.2, 7.0], [13.3, 7.0], [13.4, 7.0], [13.5, 7.0], [13.6, 7.0], [13.7, 7.0], [13.8, 7.0], [13.9, 7.0], [14.0, 7.0], [14.1, 7.0], [14.2, 7.0], [14.3, 7.0], [14.4, 7.0], [14.5, 7.0], [14.6, 7.0], [14.7, 8.0], [14.8, 8.0], [14.9, 8.0], [15.0, 8.0], [15.1, 8.0], [15.2, 8.0], [15.3, 8.0], [15.4, 8.0], [15.5, 8.0], [15.6, 8.0], [15.7, 8.0], [15.8, 8.0], [15.9, 8.0], [16.0, 8.0], [16.1, 8.0], [16.2, 8.0], [16.3, 9.0], [16.4, 9.0], [16.5, 9.0], [16.6, 9.0], [16.7, 9.0], [16.8, 9.0], [16.9, 9.0], [17.0, 9.0], [17.1, 9.0], [17.2, 9.0], [17.3, 9.0], [17.4, 9.0], [17.5, 9.0], [17.6, 9.0], [17.7, 9.0], [17.8, 9.0], [17.9, 10.0], [18.0, 10.0], [18.1, 10.0], [18.2, 10.0], [18.3, 10.0], [18.4, 10.0], [18.5, 10.0], [18.6, 10.0], [18.7, 10.0], [18.8, 10.0], [18.9, 10.0], [19.0, 10.0], [19.1, 10.0], [19.2, 10.0], [19.3, 10.0], [19.4, 10.0], [19.5, 11.0], [19.6, 11.0], [19.7, 11.0], [19.8, 11.0], [19.9, 11.0], [20.0, 11.0], [20.1, 11.0], [20.2, 11.0], [20.3, 11.0], [20.4, 11.0], [20.5, 11.0], [20.6, 11.0], [20.7, 11.0], [20.8, 11.0], [20.9, 11.0], [21.0, 11.0], [21.1, 11.0], [21.2, 11.0], [21.3, 12.0], [21.4, 12.0], [21.5, 12.0], [21.6, 12.0], [21.7, 12.0], [21.8, 12.0], [21.9, 12.0], [22.0, 12.0], [22.1, 12.0], [22.2, 12.0], [22.3, 12.0], [22.4, 12.0], [22.5, 12.0], [22.6, 12.0], [22.7, 12.0], [22.8, 12.0], [22.9, 12.0], [23.0, 12.0], [23.1, 12.0], [23.2, 12.0], [23.3, 12.0], [23.4, 13.0], [23.5, 13.0], [23.6, 13.0], [23.7, 13.0], [23.8, 13.0], [23.9, 13.0], [24.0, 13.0], [24.1, 13.0], [24.2, 13.0], [24.3, 13.0], [24.4, 13.0], [24.5, 13.0], [24.6, 13.0], [24.7, 13.0], [24.8, 13.0], [24.9, 13.0], [25.0, 13.0], [25.1, 13.0], [25.2, 13.0], [25.3, 13.0], [25.4, 13.0], [25.5, 13.0], [25.6, 13.0], [25.7, 13.0], [25.8, 13.0], [25.9, 14.0], [26.0, 14.0], [26.1, 14.0], [26.2, 14.0], [26.3, 14.0], [26.4, 14.0], [26.5, 14.0], [26.6, 14.0], [26.7, 14.0], [26.8, 14.0], [26.9, 14.0], [27.0, 14.0], [27.1, 14.0], [27.2, 14.0], [27.3, 14.0], [27.4, 14.0], [27.5, 14.0], [27.6, 14.0], [27.7, 14.0], [27.8, 14.0], [27.9, 14.0], [28.0, 14.0], [28.1, 14.0], [28.2, 14.0], [28.3, 15.0], [28.4, 15.0], [28.5, 15.0], [28.6, 15.0], [28.7, 15.0], [28.8, 15.0], [28.9, 15.0], [29.0, 15.0], [29.1, 15.0], [29.2, 15.0], [29.3, 15.0], [29.4, 15.0], [29.5, 15.0], [29.6, 15.0], [29.7, 15.0], [29.8, 15.0], [29.9, 15.0], [30.0, 15.0], [30.1, 15.0], [30.2, 15.0], [30.3, 15.0], [30.4, 15.0], [30.5, 15.0], [30.6, 15.0], [30.7, 15.0], [30.8, 15.0], [30.9, 15.0], [31.0, 16.0], [31.1, 16.0], [31.2, 16.0], [31.3, 16.0], [31.4, 16.0], [31.5, 16.0], [31.6, 16.0], [31.7, 16.0], [31.8, 16.0], [31.9, 16.0], [32.0, 16.0], [32.1, 16.0], [32.2, 16.0], [32.3, 16.0], [32.4, 16.0], [32.5, 16.0], [32.6, 16.0], [32.7, 16.0], [32.8, 16.0], [32.9, 16.0], [33.0, 16.0], [33.1, 16.0], [33.2, 16.0], [33.3, 16.0], [33.4, 16.0], [33.5, 16.0], [33.6, 16.0], [33.7, 16.0], [33.8, 17.0], [33.9, 17.0], [34.0, 17.0], [34.1, 17.0], [34.2, 17.0], [34.3, 17.0], [34.4, 17.0], [34.5, 17.0], [34.6, 17.0], [34.7, 17.0], [34.8, 17.0], [34.9, 17.0], [35.0, 17.0], [35.1, 17.0], [35.2, 17.0], [35.3, 17.0], [35.4, 17.0], [35.5, 17.0], [35.6, 17.0], [35.7, 17.0], [35.8, 17.0], [35.9, 17.0], [36.0, 17.0], [36.1, 17.0], [36.2, 17.0], [36.3, 17.0], [36.4, 17.0], [36.5, 17.0], [36.6, 18.0], [36.7, 18.0], [36.8, 18.0], [36.9, 18.0], [37.0, 18.0], [37.1, 18.0], [37.2, 18.0], [37.3, 18.0], [37.4, 18.0], [37.5, 18.0], [37.6, 18.0], [37.7, 18.0], [37.8, 18.0], [37.9, 18.0], [38.0, 18.0], [38.1, 18.0], [38.2, 18.0], [38.3, 18.0], [38.4, 18.0], [38.5, 18.0], [38.6, 18.0], [38.7, 18.0], [38.8, 18.0], [38.9, 18.0], [39.0, 19.0], [39.1, 19.0], [39.2, 19.0], [39.3, 19.0], [39.4, 19.0], [39.5, 19.0], [39.6, 19.0], [39.7, 19.0], [39.8, 19.0], [39.9, 19.0], [40.0, 19.0], [40.1, 19.0], [40.2, 19.0], [40.3, 19.0], [40.4, 19.0], [40.5, 19.0], [40.6, 19.0], [40.7, 19.0], [40.8, 19.0], [40.9, 19.0], [41.0, 19.0], [41.1, 19.0], [41.2, 19.0], [41.3, 19.0], [41.4, 19.0], [41.5, 20.0], [41.6, 20.0], [41.7, 20.0], [41.8, 20.0], [41.9, 20.0], [42.0, 20.0], [42.1, 20.0], [42.2, 20.0], [42.3, 20.0], [42.4, 20.0], [42.5, 20.0], [42.6, 20.0], [42.7, 20.0], [42.8, 20.0], [42.9, 20.0], [43.0, 20.0], [43.1, 20.0], [43.2, 20.0], [43.3, 20.0], [43.4, 20.0], [43.5, 20.0], [43.6, 20.0], [43.7, 20.0], [43.8, 20.0], [43.9, 20.0], [44.0, 20.0], [44.1, 21.0], [44.2, 21.0], [44.3, 21.0], [44.4, 21.0], [44.5, 21.0], [44.6, 21.0], [44.7, 21.0], [44.8, 21.0], [44.9, 21.0], [45.0, 21.0], [45.1, 21.0], [45.2, 21.0], [45.3, 21.0], [45.4, 21.0], [45.5, 21.0], [45.6, 21.0], [45.7, 21.0], [45.8, 21.0], [45.9, 21.0], [46.0, 21.0], [46.1, 21.0], [46.2, 22.0], [46.3, 22.0], [46.4, 22.0], [46.5, 22.0], [46.6, 22.0], [46.7, 22.0], [46.8, 22.0], [46.9, 22.0], [47.0, 22.0], [47.1, 22.0], [47.2, 22.0], [47.3, 22.0], [47.4, 22.0], [47.5, 22.0], [47.6, 22.0], [47.7, 22.0], [47.8, 22.0], [47.9, 22.0], [48.0, 22.0], [48.1, 22.0], [48.2, 23.0], [48.3, 23.0], [48.4, 23.0], [48.5, 23.0], [48.6, 23.0], [48.7, 23.0], [48.8, 23.0], [48.9, 23.0], [49.0, 23.0], [49.1, 23.0], [49.2, 23.0], [49.3, 23.0], [49.4, 23.0], [49.5, 23.0], [49.6, 23.0], [49.7, 23.0], [49.8, 23.0], [49.9, 23.0], [50.0, 23.0], [50.1, 23.0], [50.2, 23.0], [50.3, 23.0], [50.4, 23.0], [50.5, 23.0], [50.6, 23.0], [50.7, 24.0], [50.8, 24.0], [50.9, 24.0], [51.0, 24.0], [51.1, 24.0], [51.2, 24.0], [51.3, 24.0], [51.4, 24.0], [51.5, 24.0], [51.6, 24.0], [51.7, 24.0], [51.8, 24.0], [51.9, 24.0], [52.0, 24.0], [52.1, 24.0], [52.2, 24.0], [52.3, 24.0], [52.4, 24.0], [52.5, 24.0], [52.6, 24.0], [52.7, 24.0], [52.8, 25.0], [52.9, 25.0], [53.0, 25.0], [53.1, 25.0], [53.2, 25.0], [53.3, 25.0], [53.4, 25.0], [53.5, 25.0], [53.6, 25.0], [53.7, 25.0], [53.8, 25.0], [53.9, 25.0], [54.0, 25.0], [54.1, 25.0], [54.2, 25.0], [54.3, 25.0], [54.4, 25.0], [54.5, 25.0], [54.6, 25.0], [54.7, 25.0], [54.8, 25.0], [54.9, 25.0], [55.0, 26.0], [55.1, 26.0], [55.2, 26.0], [55.3, 26.0], [55.4, 26.0], [55.5, 26.0], [55.6, 26.0], [55.7, 26.0], [55.8, 26.0], [55.9, 26.0], [56.0, 26.0], [56.1, 26.0], [56.2, 26.0], [56.3, 26.0], [56.4, 26.0], [56.5, 26.0], [56.6, 26.0], [56.7, 26.0], [56.8, 26.0], [56.9, 26.0], [57.0, 26.0], [57.1, 26.0], [57.2, 26.0], [57.3, 27.0], [57.4, 27.0], [57.5, 27.0], [57.6, 27.0], [57.7, 27.0], [57.8, 27.0], [57.9, 27.0], [58.0, 27.0], [58.1, 27.0], [58.2, 27.0], [58.3, 27.0], [58.4, 27.0], [58.5, 27.0], [58.6, 27.0], [58.7, 27.0], [58.8, 27.0], [58.9, 27.0], [59.0, 27.0], [59.1, 27.0], [59.2, 27.0], [59.3, 27.0], [59.4, 28.0], [59.5, 28.0], [59.6, 28.0], [59.7, 28.0], [59.8, 28.0], [59.9, 28.0], [60.0, 28.0], [60.1, 28.0], [60.2, 28.0], [60.3, 28.0], [60.4, 28.0], [60.5, 28.0], [60.6, 28.0], [60.7, 28.0], [60.8, 28.0], [60.9, 28.0], [61.0, 28.0], [61.1, 28.0], [61.2, 28.0], [61.3, 28.0], [61.4, 28.0], [61.5, 29.0], [61.6, 29.0], [61.7, 29.0], [61.8, 29.0], [61.9, 29.0], [62.0, 29.0], [62.1, 29.0], [62.2, 29.0], [62.3, 29.0], [62.4, 29.0], [62.5, 29.0], [62.6, 29.0], [62.7, 29.0], [62.8, 29.0], [62.9, 29.0], [63.0, 29.0], [63.1, 29.0], [63.2, 29.0], [63.3, 29.0], [63.4, 29.0], [63.5, 29.0], [63.6, 30.0], [63.7, 30.0], [63.8, 30.0], [63.9, 30.0], [64.0, 30.0], [64.1, 30.0], [64.2, 30.0], [64.3, 30.0], [64.4, 30.0], [64.5, 30.0], [64.6, 30.0], [64.7, 30.0], [64.8, 30.0], [64.9, 30.0], [65.0, 30.0], [65.1, 30.0], [65.2, 30.0], [65.3, 30.0], [65.4, 30.0], [65.5, 30.0], [65.6, 31.0], [65.7, 31.0], [65.8, 31.0], [65.9, 31.0], [66.0, 31.0], [66.1, 31.0], [66.2, 31.0], [66.3, 31.0], [66.4, 31.0], [66.5, 31.0], [66.6, 31.0], [66.7, 31.0], [66.8, 31.0], [66.9, 31.0], [67.0, 31.0], [67.1, 31.0], [67.2, 31.0], [67.3, 31.0], [67.4, 31.0], [67.5, 31.0], [67.6, 32.0], [67.7, 32.0], [67.8, 32.0], [67.9, 32.0], [68.0, 32.0], [68.1, 32.0], [68.2, 32.0], [68.3, 32.0], [68.4, 32.0], [68.5, 32.0], [68.6, 32.0], [68.7, 32.0], [68.8, 32.0], [68.9, 32.0], [69.0, 32.0], [69.1, 32.0], [69.2, 32.0], [69.3, 32.0], [69.4, 32.0], [69.5, 32.0], [69.6, 33.0], [69.7, 33.0], [69.8, 33.0], [69.9, 33.0], [70.0, 33.0], [70.1, 33.0], [70.2, 33.0], [70.3, 33.0], [70.4, 33.0], [70.5, 33.0], [70.6, 33.0], [70.7, 33.0], [70.8, 33.0], [70.9, 33.0], [71.0, 33.0], [71.1, 33.0], [71.2, 33.0], [71.3, 33.0], [71.4, 34.0], [71.5, 34.0], [71.6, 34.0], [71.7, 34.0], [71.8, 34.0], [71.9, 34.0], [72.0, 34.0], [72.1, 34.0], [72.2, 34.0], [72.3, 34.0], [72.4, 34.0], [72.5, 34.0], [72.6, 34.0], [72.7, 34.0], [72.8, 34.0], [72.9, 34.0], [73.0, 34.0], [73.1, 34.0], [73.2, 35.0], [73.3, 35.0], [73.4, 35.0], [73.5, 35.0], [73.6, 35.0], [73.7, 35.0], [73.8, 35.0], [73.9, 35.0], [74.0, 35.0], [74.1, 35.0], [74.2, 35.0], [74.3, 35.0], [74.4, 35.0], [74.5, 35.0], [74.6, 35.0], [74.7, 35.0], [74.8, 35.0], [74.9, 36.0], [75.0, 36.0], [75.1, 36.0], [75.2, 36.0], [75.3, 36.0], [75.4, 36.0], [75.5, 36.0], [75.6, 36.0], [75.7, 36.0], [75.8, 36.0], [75.9, 36.0], [76.0, 36.0], [76.1, 36.0], [76.2, 36.0], [76.3, 36.0], [76.4, 36.0], [76.5, 36.0], [76.6, 36.0], [76.7, 37.0], [76.8, 37.0], [76.9, 37.0], [77.0, 37.0], [77.1, 37.0], [77.2, 37.0], [77.3, 37.0], [77.4, 37.0], [77.5, 37.0], [77.6, 37.0], [77.7, 37.0], [77.8, 37.0], [77.9, 37.0], [78.0, 37.0], [78.1, 37.0], [78.2, 38.0], [78.3, 38.0], [78.4, 38.0], [78.5, 38.0], [78.6, 38.0], [78.7, 38.0], [78.8, 38.0], [78.9, 38.0], [79.0, 38.0], [79.1, 38.0], [79.2, 38.0], [79.3, 38.0], [79.4, 38.0], [79.5, 38.0], [79.6, 38.0], [79.7, 39.0], [79.8, 39.0], [79.9, 39.0], [80.0, 39.0], [80.1, 39.0], [80.2, 39.0], [80.3, 39.0], [80.4, 39.0], [80.5, 39.0], [80.6, 39.0], [80.7, 39.0], [80.8, 39.0], [80.9, 39.0], [81.0, 39.0], [81.1, 40.0], [81.2, 40.0], [81.3, 40.0], [81.4, 40.0], [81.5, 40.0], [81.6, 40.0], [81.7, 40.0], [81.8, 40.0], [81.9, 40.0], [82.0, 40.0], [82.1, 40.0], [82.2, 40.0], [82.3, 41.0], [82.4, 41.0], [82.5, 41.0], [82.6, 41.0], [82.7, 41.0], [82.8, 41.0], [82.9, 41.0], [83.0, 41.0], [83.1, 41.0], [83.2, 41.0], [83.3, 41.0], [83.4, 41.0], [83.5, 41.0], [83.6, 42.0], [83.7, 42.0], [83.8, 42.0], [83.9, 42.0], [84.0, 42.0], [84.1, 42.0], [84.2, 42.0], [84.3, 42.0], [84.4, 42.0], [84.5, 42.0], [84.6, 42.0], [84.7, 43.0], [84.8, 43.0], [84.9, 43.0], [85.0, 43.0], [85.1, 43.0], [85.2, 43.0], [85.3, 43.0], [85.4, 43.0], [85.5, 43.0], [85.6, 43.0], [85.7, 43.0], [85.8, 43.0], [85.9, 44.0], [86.0, 44.0], [86.1, 44.0], [86.2, 44.0], [86.3, 44.0], [86.4, 44.0], [86.5, 44.0], [86.6, 44.0], [86.7, 44.0], [86.8, 44.0], [86.9, 45.0], [87.0, 45.0], [87.1, 45.0], [87.2, 45.0], [87.3, 45.0], [87.4, 45.0], [87.5, 45.0], [87.6, 45.0], [87.7, 45.0], [87.8, 45.0], [87.9, 46.0], [88.0, 46.0], [88.1, 46.0], [88.2, 46.0], [88.3, 46.0], [88.4, 46.0], [88.5, 46.0], [88.6, 46.0], [88.7, 46.0], [88.8, 47.0], [88.9, 47.0], [89.0, 47.0], [89.1, 47.0], [89.2, 47.0], [89.3, 47.0], [89.4, 47.0], [89.5, 47.0], [89.6, 48.0], [89.7, 48.0], [89.8, 48.0], [89.9, 48.0], [90.0, 48.0], [90.1, 48.0], [90.2, 48.0], [90.3, 49.0], [90.4, 49.0], [90.5, 49.0], [90.6, 49.0], [90.7, 49.0], [90.8, 49.0], [90.9, 49.0], [91.0, 49.0], [91.1, 50.0], [91.2, 50.0], [91.3, 50.0], [91.4, 50.0], [91.5, 50.0], [91.6, 50.0], [91.7, 51.0], [91.8, 51.0], [91.9, 51.0], [92.0, 51.0], [92.1, 51.0], [92.2, 51.0], [92.3, 51.0], [92.4, 52.0], [92.5, 52.0], [92.6, 52.0], [92.7, 52.0], [92.8, 52.0], [92.9, 52.0], [93.0, 53.0], [93.1, 53.0], [93.2, 53.0], [93.3, 53.0], [93.4, 53.0], [93.5, 53.0], [93.6, 54.0], [93.7, 54.0], [93.8, 54.0], [93.9, 54.0], [94.0, 54.0], [94.1, 55.0], [94.2, 55.0], [94.3, 55.0], [94.4, 55.0], [94.5, 56.0], [94.6, 56.0], [94.7, 56.0], [94.8, 56.0], [94.9, 56.0], [95.0, 57.0], [95.1, 57.0], [95.2, 57.0], [95.3, 58.0], [95.4, 58.0], [95.5, 58.0], [95.6, 58.0], [95.7, 58.0], [95.8, 59.0], [95.9, 59.0], [96.0, 59.0], [96.1, 60.0], [96.2, 60.0], [96.3, 60.0], [96.4, 61.0], [96.5, 61.0], [96.6, 61.0], [96.7, 62.0], [96.8, 62.0], [96.9, 63.0], [97.0, 63.0], [97.1, 64.0], [97.2, 64.0], [97.3, 65.0], [97.4, 65.0], [97.5, 66.0], [97.6, 66.0], [97.7, 67.0], [97.8, 68.0], [97.9, 68.0], [98.0, 68.0], [98.1, 69.0], [98.2, 70.0], [98.3, 70.0], [98.4, 71.0], [98.5, 72.0], [98.6, 73.0], [98.7, 74.0], [98.8, 75.0], [98.9, 76.0], [99.0, 77.0], [99.1, 79.0], [99.2, 80.0], [99.3, 82.0], [99.4, 83.0], [99.5, 86.0], [99.6, 88.0], [99.7, 92.0], [99.8, 97.0], [99.9, 112.0]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 47.0, "minX": 0.0, "maxY": 29953.0, "series": [{"data": [[0.0, 29953.0], [100.0, 47.0]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 30000.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 30000.0, "series": [{"data": [[0.0, 30000.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 4.9E-324, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 4.152454780361755, "minX": 1.792732209E12, "maxY": 50.0, "series": [{"data": [[1.792732218E12, 50.0], [1.792732217E12, 50.0], [1.792732216E12, 50.0], [1.792732215E12, 50.0], [1.792732214E12, 49.42108709888673], [1.792732224E12, 42.047207446808535], [1.792732223E12, 43.81945327399873], [1.792732222E12, 46.0], [1.792732221E12, 46.80392156862748], [1.79273222E12, 48.431833445265234], [1.792732219E12, 49.989879822896896], [1.792732229E12, 11.598496240601504], [1.792732228E12, 23.8215488215488], [1.792732227E12, 32.434810126582256], [1.792732226E12, 37.17029702970295], [1.792732225E12, 40.85993265993268], [1.792732213E12, 41.69512195121961], [1.792732212E12, 31.764132553606224], [1.792732211E12, 21.57933333333336], [1.79273221E12, 11.194909578030794], [1.792732209E12, 4.152454780361755]], "isOverall": false, "label": "线程组", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732229E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 1.3529411764705885, "minX": 1.0, "maxY": 32.25181405895697, "series": [{"data": [[2.0, 4.000000000000001], [3.0, 2.4299065420560746], [4.0, 2.5985401459854023], [5.0, 5.096774193548387], [6.0, 4.556962025316455], [7.0, 4.4567901234567895], [8.0, 4.936781609195404], [9.0, 5.8488372093023235], [10.0, 7.0703124999999964], [11.0, 7.7428571428571376], [12.0, 7.724137931034486], [13.0, 7.684848484848482], [14.0, 9.880382775119621], [15.0, 11.156249999999998], [16.0, 10.492537313432829], [17.0, 11.433526011560698], [18.0, 12.724025974025968], [19.0, 11.725146198830407], [20.0, 12.62795698924732], [21.0, 13.069767441860467], [22.0, 13.768817204301074], [23.0, 14.389776357827479], [24.0, 14.826086956521742], [25.0, 18.311787072243344], [26.0, 17.552419354838698], [27.0, 18.028481012658236], [28.0, 19.443708609271535], [29.0, 21.776397515527954], [30.0, 20.28336380255938], [31.0, 19.22115384615385], [32.0, 20.119383825417206], [33.0, 20.4353448275862], [34.0, 21.180478821362797], [35.0, 23.243961352657003], [36.0, 24.276543209876557], [37.0, 23.39999999999999], [38.0, 23.566308243727597], [39.0, 25.595911949685547], [40.0, 27.063241106719374], [41.0, 28.143103448275873], [42.0, 28.097906055461195], [43.0, 27.905317769130985], [44.0, 27.787790697674403], [45.0, 28.402515723270447], [46.0, 30.78095238095235], [47.0, 30.54114994363018], [48.0, 32.107296137339056], [49.0, 32.20486985726283], [50.0, 32.25181405895697], [1.0, 1.3529411764705885]], "isOverall": false, "label": "Products", "isController": false}, {"data": [[39.34640000000006, 25.72159999999994]], "isOverall": false, "label": "Products-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 50.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 98736.0, "minX": 1.792732209E12, "maxY": 757620.0, "series": [{"data": [[1.792732218E12, 757620.0], [1.792732217E12, 724705.0], [1.792732216E12, 708218.0], [1.792732215E12, 733314.0], [1.792732214E12, 720217.0], [1.792732224E12, 709253.0], [1.792732223E12, 743934.0], [1.792732222E12, 710313.0], [1.792732221E12, 723828.0], [1.79273222E12, 706385.0], [1.792732219E12, 745569.0], [1.792732229E12, 314388.0], [1.792732228E12, 702733.0], [1.792732227E12, 748080.0], [1.792732226E12, 717024.0], [1.792732225E12, 704387.0], [1.792732213E12, 698363.0], [1.792732212E12, 730564.0], [1.792732211E12, 709036.0], [1.79273221E12, 706889.0], [1.792732209E12, 185039.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792732218E12, 408716.0], [1.792732217E12, 389846.0], [1.792732216E12, 381906.0], [1.792732215E12, 394438.0], [1.792732214E12, 389579.0], [1.792732224E12, 383691.0], [1.792732223E12, 401324.0], [1.792732222E12, 382188.0], [1.792732221E12, 390325.0], [1.79273222E12, 379895.0], [1.792732219E12, 403350.0], [1.792732229E12, 169639.0], [1.792732228E12, 378878.0], [1.792732227E12, 403110.0], [1.792732226E12, 386493.0], [1.792732225E12, 378888.0], [1.792732213E12, 376553.0], [1.792732212E12, 392668.0], [1.792732211E12, 382664.0], [1.79273221E12, 380918.0], [1.792732209E12, 98736.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732229E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 3.71059431524548, "minX": 1.792732209E12, "maxY": 33.56913827655307, "series": [{"data": [[1.792732218E12, 31.17915106117353], [1.792732217E12, 32.706151832460655], [1.792732216E12, 33.56913827655307], [1.792732215E12, 32.212160413971496], [1.792732214E12, 32.14800261951547], [1.792732224E12, 27.97207446808509], [1.792732223E12, 27.99364272091543], [1.792732222E12, 30.849799732977367], [1.792732221E12, 30.31503267973853], [1.79273222E12, 32.428475486903935], [1.792732219E12, 31.392156862745086], [1.792732229E12, 8.189473684210522], [1.792732228E12, 16.45656565656568], [1.792732227E12, 20.487341772151904], [1.792732226E12, 24.41320132013201], [1.792732225E12, 27.470707070707075], [1.792732213E12, 27.853658536585368], [1.792732212E12, 20.311890838206608], [1.792732211E12, 14.175999999999998], [1.79273221E12, 7.273275284661746], [1.792732209E12, 3.71059431524548]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732229E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 3.6821705426356606, "minX": 1.792732209E12, "maxY": 33.56713426853705, "series": [{"data": [[1.792732218E12, 31.177902621722843], [1.792732217E12, 32.69960732984295], [1.792732216E12, 33.56713426853705], [1.792732215E12, 32.20569210866747], [1.792732214E12, 32.144728225278335], [1.792732224E12, 27.97074468085105], [1.792732223E12, 27.990464081373194], [1.792732222E12, 30.846461949265663], [1.792732221E12, 30.311764705882315], [1.79273222E12, 32.422431161853574], [1.792732219E12, 31.388361796331473], [1.792732229E12, 8.186466165413538], [1.792732228E12, 16.4552188552189], [1.792732227E12, 20.484810126582257], [1.792732226E12, 24.411881188118834], [1.792732225E12, 27.46801346801345], [1.792732213E12, 27.84891598915989], [1.792732212E12, 20.306692657569872], [1.792732211E12, 14.169999999999986], [1.79273221E12, 7.266577361018092], [1.792732209E12, 3.6821705426356606]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732229E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792732209E12, "maxY": 0.10077519379844962, "series": [{"data": [[1.792732218E12, 0.001872659176029964], [1.792732217E12, 0.006544502617801054], [1.792732216E12, 0.004676018704074828], [1.792732215E12, 0.0064683053040103565], [1.792732214E12, 0.003929273084479369], [1.792732224E12, 0.005984042553191498], [1.792732223E12, 0.0019071837253655441], [1.792732222E12, 0.0013351134846461975], [1.792732221E12, 0.003921568627450979], [1.79273222E12, 0.006044325050369377], [1.792732219E12, 0.002530044275774831], [1.792732229E12, 0.0], [1.792732228E12, 0.004040404040404042], [1.792732227E12, 0.0012658227848101312], [1.792732226E12, 0.0046204620462046275], [1.792732225E12, 0.003367003367003371], [1.792732213E12, 0.008807588075880758], [1.792732212E12, 0.005198180636777139], [1.792732211E12, 0.010666666666666685], [1.79273221E12, 0.01339584728734092], [1.792732209E12, 0.10077519379844962]], "isOverall": false, "label": "Products", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732229E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 1.0, "minX": 1.792732209E12, "maxY": 166.0, "series": [{"data": [[1.792732218E12, 118.0], [1.792732217E12, 146.0], [1.792732216E12, 154.0], [1.792732215E12, 122.0], [1.792732214E12, 157.0], [1.792732224E12, 127.0], [1.792732223E12, 137.0], [1.792732222E12, 109.0], [1.792732221E12, 132.0], [1.79273222E12, 153.0], [1.792732219E12, 138.0], [1.792732229E12, 65.0], [1.792732228E12, 148.0], [1.792732227E12, 98.0], [1.792732226E12, 131.0], [1.792732225E12, 166.0], [1.792732213E12, 98.0], [1.792732212E12, 72.0], [1.792732211E12, 95.0], [1.79273221E12, 44.0], [1.792732209E12, 28.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792732218E12, 2.0], [1.792732217E12, 1.0], [1.792732216E12, 1.0], [1.792732215E12, 1.0], [1.792732214E12, 1.0], [1.792732224E12, 1.0], [1.792732223E12, 1.0], [1.792732222E12, 1.0], [1.792732221E12, 2.0], [1.79273222E12, 1.0], [1.792732219E12, 1.0], [1.792732229E12, 1.0], [1.792732228E12, 1.0], [1.792732227E12, 1.0], [1.792732226E12, 1.0], [1.792732225E12, 1.0], [1.792732213E12, 1.0], [1.792732212E12, 1.0], [1.792732211E12, 2.0], [1.79273221E12, 2.0], [1.792732209E12, 1.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792732218E12, 51.0], [1.792732217E12, 56.0], [1.792732216E12, 59.0], [1.792732215E12, 54.0], [1.792732214E12, 56.0], [1.792732224E12, 49.0], [1.792732223E12, 46.0], [1.792732222E12, 53.0], [1.792732221E12, 51.0], [1.79273222E12, 60.0], [1.792732219E12, 50.799999999999955], [1.792732229E12, 16.0], [1.792732228E12, 33.0], [1.792732227E12, 36.0], [1.792732226E12, 43.40000000000009], [1.792732225E12, 49.0], [1.792732213E12, 48.0], [1.792732212E12, 34.0], [1.792732211E12, 24.0], [1.79273221E12, 13.0], [1.792732209E12, 6.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792732218E12, 77.0], [1.792732217E12, 87.0], [1.792732216E12, 93.0], [1.792732215E12, 78.0], [1.792732214E12, 80.0], [1.792732224E12, 74.0], [1.792732223E12, 70.77999999999997], [1.792732222E12, 82.00999999999999], [1.792732221E12, 76.69000000000005], [1.79273222E12, 95.0], [1.792732219E12, 76.18000000000006], [1.792732229E12, 35.680000000000064], [1.792732228E12, 59.1400000000001], [1.792732227E12, 60.190000000000055], [1.792732226E12, 73.35999999999967], [1.792732225E12, 75.0], [1.792732213E12, 71.23000000000002], [1.792732212E12, 51.59999999999991], [1.792732211E12, 45.0], [1.79273221E12, 26.059999999999945], [1.792732209E12, 20.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792732218E12, 30.0], [1.792732217E12, 30.5], [1.792732216E12, 32.0], [1.792732215E12, 31.0], [1.792732214E12, 30.0], [1.792732224E12, 26.0], [1.792732223E12, 26.0], [1.792732222E12, 29.0], [1.792732221E12, 29.0], [1.79273222E12, 30.0], [1.792732219E12, 30.0], [1.792732229E12, 6.0], [1.792732228E12, 13.0], [1.792732227E12, 19.0], [1.792732226E12, 22.0], [1.792732225E12, 25.0], [1.792732213E12, 27.0], [1.792732212E12, 19.0], [1.792732211E12, 12.0], [1.79273221E12, 6.0], [1.792732209E12, 3.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792732218E12, 58.0], [1.792732217E12, 63.549999999999955], [1.792732216E12, 70.0], [1.792732215E12, 63.0], [1.792732214E12, 64.0], [1.792732224E12, 57.0], [1.792732223E12, 52.0], [1.792732222E12, 61.0], [1.792732221E12, 59.450000000000045], [1.79273222E12, 73.0], [1.792732219E12, 58.0], [1.792732229E12, 21.699999999999932], [1.792732228E12, 42.700000000000045], [1.792732227E12, 42.94999999999982], [1.792732226E12, 51.0], [1.792732225E12, 56.0], [1.792732213E12, 55.0], [1.792732212E12, 41.0], [1.792732211E12, 29.0], [1.79273221E12, 17.0], [1.792732209E12, 8.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732229E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 3.0, "minX": 387.0, "maxY": 32.0, "series": [{"data": [[665.0, 6.0], [1500.0, 12.0], [1493.0, 6.0], [1476.0, 27.0], [1485.0, 19.0], [1527.0, 30.0], [1497.0, 32.0], [1528.0, 30.5], [1489.0, 30.0], [1530.0, 29.0], [1498.0, 29.0], [1504.0, 26.0], [1515.0, 22.0], [1539.0, 19.0], [1546.0, 31.0], [1581.0, 30.0], [1573.0, 26.0], [1580.0, 19.0], [1602.0, 30.0], [387.0, 3.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1602.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 3.0, "minX": 387.0, "maxY": 32.0, "series": [{"data": [[665.0, 6.0], [1500.0, 12.0], [1493.0, 6.0], [1476.0, 27.0], [1485.0, 19.0], [1527.0, 30.0], [1497.0, 32.0], [1528.0, 30.5], [1489.0, 30.0], [1530.0, 29.0], [1498.0, 29.0], [1504.0, 26.0], [1515.0, 22.0], [1539.0, 19.0], [1546.0, 31.0], [1581.0, 30.0], [1573.0, 26.0], [1580.0, 19.0], [1602.0, 30.0], [387.0, 3.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1602.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 393.0, "minX": 1.792732209E12, "maxY": 1602.0, "series": [{"data": [[1.792732218E12, 1602.0], [1.792732217E12, 1528.0], [1.792732216E12, 1497.0], [1.792732215E12, 1546.0], [1.792732214E12, 1530.0], [1.792732224E12, 1503.0], [1.792732223E12, 1570.0], [1.792732222E12, 1498.0], [1.792732221E12, 1529.0], [1.79273222E12, 1487.0], [1.792732219E12, 1580.0], [1.792732229E12, 647.0], [1.792732228E12, 1473.0], [1.792732227E12, 1575.0], [1.792732226E12, 1512.0], [1.792732225E12, 1481.0], [1.792732213E12, 1486.0], [1.792732212E12, 1549.0], [1.792732211E12, 1511.0], [1.79273221E12, 1503.0], [1.792732209E12, 393.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732229E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 387.0, "minX": 1.792732209E12, "maxY": 1602.0, "series": [{"data": [[1.792732218E12, 1602.0], [1.792732217E12, 1528.0], [1.792732216E12, 1497.0], [1.792732215E12, 1546.0], [1.792732214E12, 1527.0], [1.792732224E12, 1504.0], [1.792732223E12, 1573.0], [1.792732222E12, 1498.0], [1.792732221E12, 1530.0], [1.79273222E12, 1489.0], [1.792732219E12, 1581.0], [1.792732229E12, 665.0], [1.792732228E12, 1485.0], [1.792732227E12, 1580.0], [1.792732226E12, 1515.0], [1.792732225E12, 1485.0], [1.792732213E12, 1476.0], [1.792732212E12, 1539.0], [1.792732211E12, 1500.0], [1.79273221E12, 1493.0], [1.792732209E12, 387.0]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732229E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 387.0, "minX": 1.792732209E12, "maxY": 1602.0, "series": [{"data": [[1.792732218E12, 1602.0], [1.792732217E12, 1528.0], [1.792732216E12, 1497.0], [1.792732215E12, 1546.0], [1.792732214E12, 1527.0], [1.792732224E12, 1504.0], [1.792732223E12, 1573.0], [1.792732222E12, 1498.0], [1.792732221E12, 1530.0], [1.79273222E12, 1489.0], [1.792732219E12, 1581.0], [1.792732229E12, 665.0], [1.792732228E12, 1485.0], [1.792732227E12, 1580.0], [1.792732226E12, 1515.0], [1.792732225E12, 1485.0], [1.792732213E12, 1476.0], [1.792732212E12, 1539.0], [1.792732211E12, 1500.0], [1.79273221E12, 1493.0], [1.792732209E12, 387.0]], "isOverall": false, "label": "Products-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732229E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 387.0, "minX": 1.792732209E12, "maxY": 1602.0, "series": [{"data": [[1.792732218E12, 1602.0], [1.792732217E12, 1528.0], [1.792732216E12, 1497.0], [1.792732215E12, 1546.0], [1.792732214E12, 1527.0], [1.792732224E12, 1504.0], [1.792732223E12, 1573.0], [1.792732222E12, 1498.0], [1.792732221E12, 1530.0], [1.79273222E12, 1489.0], [1.792732219E12, 1581.0], [1.792732229E12, 665.0], [1.792732228E12, 1485.0], [1.792732227E12, 1580.0], [1.792732226E12, 1515.0], [1.792732225E12, 1485.0], [1.792732213E12, 1476.0], [1.792732212E12, 1539.0], [1.792732211E12, 1500.0], [1.79273221E12, 1493.0], [1.792732209E12, 387.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732229E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}


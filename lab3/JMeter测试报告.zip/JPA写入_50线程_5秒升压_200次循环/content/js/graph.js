/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 5.0, "minX": 0.0, "maxY": 250.0, "series": [{"data": [[0.0, 5.0], [0.1, 5.0], [0.2, 5.0], [0.3, 6.0], [0.4, 6.0], [0.5, 6.0], [0.6, 6.0], [0.7, 6.0], [0.8, 6.0], [0.9, 6.0], [1.0, 6.0], [1.1, 6.0], [1.2, 6.0], [1.3, 7.0], [1.4, 7.0], [1.5, 7.0], [1.6, 7.0], [1.7, 7.0], [1.8, 7.0], [1.9, 7.0], [2.0, 7.0], [2.1, 7.0], [2.2, 7.0], [2.3, 7.0], [2.4, 7.0], [2.5, 7.0], [2.6, 8.0], [2.7, 8.0], [2.8, 8.0], [2.9, 8.0], [3.0, 8.0], [3.1, 8.0], [3.2, 8.0], [3.3, 8.0], [3.4, 8.0], [3.5, 8.0], [3.6, 8.0], [3.7, 8.0], [3.8, 8.0], [3.9, 8.0], [4.0, 8.0], [4.1, 9.0], [4.2, 9.0], [4.3, 9.0], [4.4, 9.0], [4.5, 9.0], [4.6, 9.0], [4.7, 9.0], [4.8, 9.0], [4.9, 9.0], [5.0, 9.0], [5.1, 9.0], [5.2, 9.0], [5.3, 9.0], [5.4, 9.0], [5.5, 10.0], [5.6, 10.0], [5.7, 10.0], [5.8, 10.0], [5.9, 10.0], [6.0, 10.0], [6.1, 10.0], [6.2, 10.0], [6.3, 10.0], [6.4, 10.0], [6.5, 10.0], [6.6, 10.0], [6.7, 10.0], [6.8, 10.0], [6.9, 11.0], [7.0, 11.0], [7.1, 11.0], [7.2, 11.0], [7.3, 11.0], [7.4, 11.0], [7.5, 11.0], [7.6, 11.0], [7.7, 11.0], [7.8, 11.0], [7.9, 11.0], [8.0, 11.0], [8.1, 11.0], [8.2, 11.0], [8.3, 12.0], [8.4, 12.0], [8.5, 12.0], [8.6, 12.0], [8.7, 12.0], [8.8, 12.0], [8.9, 12.0], [9.0, 12.0], [9.1, 12.0], [9.2, 12.0], [9.3, 12.0], [9.4, 12.0], [9.5, 12.0], [9.6, 13.0], [9.7, 13.0], [9.8, 13.0], [9.9, 13.0], [10.0, 13.0], [10.1, 13.0], [10.2, 13.0], [10.3, 13.0], [10.4, 13.0], [10.5, 13.0], [10.6, 13.0], [10.7, 13.0], [10.8, 13.0], [10.9, 14.0], [11.0, 14.0], [11.1, 14.0], [11.2, 14.0], [11.3, 14.0], [11.4, 14.0], [11.5, 14.0], [11.6, 14.0], [11.7, 14.0], [11.8, 14.0], [11.9, 14.0], [12.0, 14.0], [12.1, 15.0], [12.2, 15.0], [12.3, 15.0], [12.4, 15.0], [12.5, 15.0], [12.6, 15.0], [12.7, 15.0], [12.8, 15.0], [12.9, 15.0], [13.0, 15.0], [13.1, 15.0], [13.2, 15.0], [13.3, 16.0], [13.4, 16.0], [13.5, 16.0], [13.6, 16.0], [13.7, 16.0], [13.8, 16.0], [13.9, 16.0], [14.0, 16.0], [14.1, 16.0], [14.2, 16.0], [14.3, 16.0], [14.4, 16.0], [14.5, 16.0], [14.6, 16.0], [14.7, 16.0], [14.8, 16.0], [14.9, 17.0], [15.0, 17.0], [15.1, 17.0], [15.2, 17.0], [15.3, 17.0], [15.4, 17.0], [15.5, 17.0], [15.6, 17.0], [15.7, 17.0], [15.8, 17.0], [15.9, 17.0], [16.0, 17.0], [16.1, 17.0], [16.2, 17.0], [16.3, 18.0], [16.4, 18.0], [16.5, 18.0], [16.6, 18.0], [16.7, 18.0], [16.8, 18.0], [16.9, 18.0], [17.0, 18.0], [17.1, 18.0], [17.2, 18.0], [17.3, 18.0], [17.4, 18.0], [17.5, 18.0], [17.6, 18.0], [17.7, 18.0], [17.8, 19.0], [17.9, 19.0], [18.0, 19.0], [18.1, 19.0], [18.2, 19.0], [18.3, 19.0], [18.4, 19.0], [18.5, 19.0], [18.6, 19.0], [18.7, 19.0], [18.8, 19.0], [18.9, 19.0], [19.0, 19.0], [19.1, 19.0], [19.2, 19.0], [19.3, 20.0], [19.4, 20.0], [19.5, 20.0], [19.6, 20.0], [19.7, 20.0], [19.8, 20.0], [19.9, 20.0], [20.0, 20.0], [20.1, 20.0], [20.2, 20.0], [20.3, 20.0], [20.4, 20.0], [20.5, 20.0], [20.6, 20.0], [20.7, 20.0], [20.8, 20.0], [20.9, 20.0], [21.0, 20.0], [21.1, 21.0], [21.2, 21.0], [21.3, 21.0], [21.4, 21.0], [21.5, 21.0], [21.6, 21.0], [21.7, 21.0], [21.8, 21.0], [21.9, 21.0], [22.0, 21.0], [22.1, 21.0], [22.2, 21.0], [22.3, 21.0], [22.4, 21.0], [22.5, 21.0], [22.6, 21.0], [22.7, 21.0], [22.8, 22.0], [22.9, 22.0], [23.0, 22.0], [23.1, 22.0], [23.2, 22.0], [23.3, 22.0], [23.4, 22.0], [23.5, 22.0], [23.6, 22.0], [23.7, 22.0], [23.8, 22.0], [23.9, 22.0], [24.0, 22.0], [24.1, 22.0], [24.2, 22.0], [24.3, 22.0], [24.4, 22.0], [24.5, 22.0], [24.6, 22.0], [24.7, 23.0], [24.8, 23.0], [24.9, 23.0], [25.0, 23.0], [25.1, 23.0], [25.2, 23.0], [25.3, 23.0], [25.4, 23.0], [25.5, 23.0], [25.6, 23.0], [25.7, 23.0], [25.8, 23.0], [25.9, 23.0], [26.0, 23.0], [26.1, 23.0], [26.2, 23.0], [26.3, 23.0], [26.4, 23.0], [26.5, 23.0], [26.6, 24.0], [26.7, 24.0], [26.8, 24.0], [26.9, 24.0], [27.0, 24.0], [27.1, 24.0], [27.2, 24.0], [27.3, 24.0], [27.4, 24.0], [27.5, 24.0], [27.6, 24.0], [27.7, 24.0], [27.8, 24.0], [27.9, 24.0], [28.0, 25.0], [28.1, 25.0], [28.2, 25.0], [28.3, 25.0], [28.4, 25.0], [28.5, 25.0], [28.6, 25.0], [28.7, 25.0], [28.8, 25.0], [28.9, 25.0], [29.0, 25.0], [29.1, 25.0], [29.2, 25.0], [29.3, 25.0], [29.4, 25.0], [29.5, 25.0], [29.6, 25.0], [29.7, 26.0], [29.8, 26.0], [29.9, 26.0], [30.0, 26.0], [30.1, 26.0], [30.2, 26.0], [30.3, 26.0], [30.4, 26.0], [30.5, 26.0], [30.6, 26.0], [30.7, 26.0], [30.8, 26.0], [30.9, 26.0], [31.0, 26.0], [31.1, 26.0], [31.2, 26.0], [31.3, 26.0], [31.4, 26.0], [31.5, 26.0], [31.6, 26.0], [31.7, 26.0], [31.8, 27.0], [31.9, 27.0], [32.0, 27.0], [32.1, 27.0], [32.2, 27.0], [32.3, 27.0], [32.4, 27.0], [32.5, 27.0], [32.6, 27.0], [32.7, 27.0], [32.8, 27.0], [32.9, 27.0], [33.0, 27.0], [33.1, 27.0], [33.2, 27.0], [33.3, 28.0], [33.4, 28.0], [33.5, 28.0], [33.6, 28.0], [33.7, 28.0], [33.8, 28.0], [33.9, 28.0], [34.0, 28.0], [34.1, 28.0], [34.2, 28.0], [34.3, 28.0], [34.4, 28.0], [34.5, 28.0], [34.6, 28.0], [34.7, 28.0], [34.8, 28.0], [34.9, 28.0], [35.0, 28.0], [35.1, 29.0], [35.2, 29.0], [35.3, 29.0], [35.4, 29.0], [35.5, 29.0], [35.6, 29.0], [35.7, 29.0], [35.8, 29.0], [35.9, 29.0], [36.0, 29.0], [36.1, 29.0], [36.2, 29.0], [36.3, 29.0], [36.4, 29.0], [36.5, 29.0], [36.6, 30.0], [36.7, 30.0], [36.8, 30.0], [36.9, 30.0], [37.0, 30.0], [37.1, 30.0], [37.2, 30.0], [37.3, 30.0], [37.4, 30.0], [37.5, 30.0], [37.6, 30.0], [37.7, 30.0], [37.8, 30.0], [37.9, 30.0], [38.0, 30.0], [38.1, 30.0], [38.2, 30.0], [38.3, 31.0], [38.4, 31.0], [38.5, 31.0], [38.6, 31.0], [38.7, 31.0], [38.8, 31.0], [38.9, 31.0], [39.0, 31.0], [39.1, 31.0], [39.2, 31.0], [39.3, 31.0], [39.4, 31.0], [39.5, 31.0], [39.6, 31.0], [39.7, 31.0], [39.8, 32.0], [39.9, 32.0], [40.0, 32.0], [40.1, 32.0], [40.2, 32.0], [40.3, 32.0], [40.4, 32.0], [40.5, 32.0], [40.6, 32.0], [40.7, 32.0], [40.8, 32.0], [40.9, 32.0], [41.0, 32.0], [41.1, 32.0], [41.2, 32.0], [41.3, 33.0], [41.4, 33.0], [41.5, 33.0], [41.6, 33.0], [41.7, 33.0], [41.8, 33.0], [41.9, 33.0], [42.0, 33.0], [42.1, 33.0], [42.2, 33.0], [42.3, 33.0], [42.4, 33.0], [42.5, 33.0], [42.6, 33.0], [42.7, 34.0], [42.8, 34.0], [42.9, 34.0], [43.0, 34.0], [43.1, 34.0], [43.2, 34.0], [43.3, 34.0], [43.4, 34.0], [43.5, 34.0], [43.6, 34.0], [43.7, 34.0], [43.8, 34.0], [43.9, 34.0], [44.0, 34.0], [44.1, 34.0], [44.2, 35.0], [44.3, 35.0], [44.4, 35.0], [44.5, 35.0], [44.6, 35.0], [44.7, 35.0], [44.8, 35.0], [44.9, 35.0], [45.0, 35.0], [45.1, 35.0], [45.2, 35.0], [45.3, 35.0], [45.4, 35.0], [45.5, 35.0], [45.6, 35.0], [45.7, 35.0], [45.8, 36.0], [45.9, 36.0], [46.0, 36.0], [46.1, 36.0], [46.2, 36.0], [46.3, 36.0], [46.4, 36.0], [46.5, 36.0], [46.6, 36.0], [46.7, 36.0], [46.8, 36.0], [46.9, 36.0], [47.0, 36.0], [47.1, 36.0], [47.2, 36.0], [47.3, 36.0], [47.4, 37.0], [47.5, 37.0], [47.6, 37.0], [47.7, 37.0], [47.8, 37.0], [47.9, 37.0], [48.0, 37.0], [48.1, 37.0], [48.2, 37.0], [48.3, 37.0], [48.4, 37.0], [48.5, 37.0], [48.6, 37.0], [48.7, 37.0], [48.8, 37.0], [48.9, 37.0], [49.0, 38.0], [49.1, 38.0], [49.2, 38.0], [49.3, 38.0], [49.4, 38.0], [49.5, 38.0], [49.6, 38.0], [49.7, 38.0], [49.8, 38.0], [49.9, 38.0], [50.0, 38.0], [50.1, 38.0], [50.2, 38.0], [50.3, 38.0], [50.4, 38.0], [50.5, 38.0], [50.6, 39.0], [50.7, 39.0], [50.8, 39.0], [50.9, 39.0], [51.0, 39.0], [51.1, 39.0], [51.2, 39.0], [51.3, 39.0], [51.4, 39.0], [51.5, 39.0], [51.6, 39.0], [51.7, 39.0], [51.8, 39.0], [51.9, 39.0], [52.0, 39.0], [52.1, 40.0], [52.2, 40.0], [52.3, 40.0], [52.4, 40.0], [52.5, 40.0], [52.6, 40.0], [52.7, 40.0], [52.8, 40.0], [52.9, 40.0], [53.0, 40.0], [53.1, 40.0], [53.2, 40.0], [53.3, 40.0], [53.4, 40.0], [53.5, 41.0], [53.6, 41.0], [53.7, 41.0], [53.8, 41.0], [53.9, 41.0], [54.0, 41.0], [54.1, 41.0], [54.2, 41.0], [54.3, 41.0], [54.4, 41.0], [54.5, 41.0], [54.6, 41.0], [54.7, 41.0], [54.8, 42.0], [54.9, 42.0], [55.0, 42.0], [55.1, 42.0], [55.2, 42.0], [55.3, 42.0], [55.4, 42.0], [55.5, 42.0], [55.6, 42.0], [55.7, 42.0], [55.8, 42.0], [55.9, 42.0], [56.0, 42.0], [56.1, 42.0], [56.2, 42.0], [56.3, 42.0], [56.4, 43.0], [56.5, 43.0], [56.6, 43.0], [56.7, 43.0], [56.8, 43.0], [56.9, 43.0], [57.0, 43.0], [57.1, 43.0], [57.2, 43.0], [57.3, 43.0], [57.4, 43.0], [57.5, 43.0], [57.6, 43.0], [57.7, 43.0], [57.8, 43.0], [57.9, 43.0], [58.0, 44.0], [58.1, 44.0], [58.2, 44.0], [58.3, 44.0], [58.4, 44.0], [58.5, 44.0], [58.6, 44.0], [58.7, 44.0], [58.8, 44.0], [58.9, 44.0], [59.0, 44.0], [59.1, 44.0], [59.2, 44.0], [59.3, 45.0], [59.4, 45.0], [59.5, 45.0], [59.6, 45.0], [59.7, 45.0], [59.8, 45.0], [59.9, 45.0], [60.0, 45.0], [60.1, 45.0], [60.2, 45.0], [60.3, 45.0], [60.4, 45.0], [60.5, 45.0], [60.6, 45.0], [60.7, 45.0], [60.8, 45.0], [60.9, 45.0], [61.0, 46.0], [61.1, 46.0], [61.2, 46.0], [61.3, 46.0], [61.4, 46.0], [61.5, 46.0], [61.6, 46.0], [61.7, 46.0], [61.8, 46.0], [61.9, 46.0], [62.0, 46.0], [62.1, 46.0], [62.2, 46.0], [62.3, 46.0], [62.4, 46.0], [62.5, 47.0], [62.6, 47.0], [62.7, 47.0], [62.8, 47.0], [62.9, 47.0], [63.0, 47.0], [63.1, 47.0], [63.2, 47.0], [63.3, 47.0], [63.4, 47.0], [63.5, 47.0], [63.6, 47.0], [63.7, 47.0], [63.8, 47.0], [63.9, 48.0], [64.0, 48.0], [64.1, 48.0], [64.2, 48.0], [64.3, 48.0], [64.4, 48.0], [64.5, 48.0], [64.6, 48.0], [64.7, 48.0], [64.8, 48.0], [64.9, 48.0], [65.0, 48.0], [65.1, 48.0], [65.2, 48.0], [65.3, 48.0], [65.4, 49.0], [65.5, 49.0], [65.6, 49.0], [65.7, 49.0], [65.8, 49.0], [65.9, 49.0], [66.0, 49.0], [66.1, 49.0], [66.2, 49.0], [66.3, 49.0], [66.4, 49.0], [66.5, 49.0], [66.6, 49.0], [66.7, 49.0], [66.8, 49.0], [66.9, 50.0], [67.0, 50.0], [67.1, 50.0], [67.2, 50.0], [67.3, 50.0], [67.4, 50.0], [67.5, 50.0], [67.6, 50.0], [67.7, 50.0], [67.8, 50.0], [67.9, 50.0], [68.0, 50.0], [68.1, 50.0], [68.2, 50.0], [68.3, 50.0], [68.4, 51.0], [68.5, 51.0], [68.6, 51.0], [68.7, 51.0], [68.8, 51.0], [68.9, 51.0], [69.0, 51.0], [69.1, 51.0], [69.2, 51.0], [69.3, 51.0], [69.4, 51.0], [69.5, 51.0], [69.6, 51.0], [69.7, 51.0], [69.8, 52.0], [69.9, 52.0], [70.0, 52.0], [70.1, 52.0], [70.2, 52.0], [70.3, 52.0], [70.4, 52.0], [70.5, 52.0], [70.6, 52.0], [70.7, 52.0], [70.8, 52.0], [70.9, 52.0], [71.0, 52.0], [71.1, 53.0], [71.2, 53.0], [71.3, 53.0], [71.4, 53.0], [71.5, 53.0], [71.6, 53.0], [71.7, 53.0], [71.8, 53.0], [71.9, 53.0], [72.0, 53.0], [72.1, 53.0], [72.2, 53.0], [72.3, 53.0], [72.4, 54.0], [72.5, 54.0], [72.6, 54.0], [72.7, 54.0], [72.8, 54.0], [72.9, 54.0], [73.0, 54.0], [73.1, 54.0], [73.2, 54.0], [73.3, 54.0], [73.4, 54.0], [73.5, 54.0], [73.6, 55.0], [73.7, 55.0], [73.8, 55.0], [73.9, 55.0], [74.0, 55.0], [74.1, 55.0], [74.2, 55.0], [74.3, 55.0], [74.4, 55.0], [74.5, 55.0], [74.6, 55.0], [74.7, 56.0], [74.8, 56.0], [74.9, 56.0], [75.0, 56.0], [75.1, 56.0], [75.2, 56.0], [75.3, 56.0], [75.4, 56.0], [75.5, 56.0], [75.6, 56.0], [75.7, 57.0], [75.8, 57.0], [75.9, 57.0], [76.0, 57.0], [76.1, 57.0], [76.2, 57.0], [76.3, 57.0], [76.4, 57.0], [76.5, 57.0], [76.6, 57.0], [76.7, 57.0], [76.8, 58.0], [76.9, 58.0], [77.0, 58.0], [77.1, 58.0], [77.2, 58.0], [77.3, 58.0], [77.4, 58.0], [77.5, 58.0], [77.6, 58.0], [77.7, 59.0], [77.8, 59.0], [77.9, 59.0], [78.0, 59.0], [78.1, 59.0], [78.2, 59.0], [78.3, 59.0], [78.4, 59.0], [78.5, 59.0], [78.6, 60.0], [78.7, 60.0], [78.8, 60.0], [78.9, 60.0], [79.0, 60.0], [79.1, 60.0], [79.2, 60.0], [79.3, 60.0], [79.4, 60.0], [79.5, 61.0], [79.6, 61.0], [79.7, 61.0], [79.8, 61.0], [79.9, 61.0], [80.0, 61.0], [80.1, 61.0], [80.2, 61.0], [80.3, 61.0], [80.4, 61.0], [80.5, 62.0], [80.6, 62.0], [80.7, 62.0], [80.8, 62.0], [80.9, 62.0], [81.0, 62.0], [81.1, 62.0], [81.2, 62.0], [81.3, 62.0], [81.4, 63.0], [81.5, 63.0], [81.6, 63.0], [81.7, 63.0], [81.8, 63.0], [81.9, 63.0], [82.0, 63.0], [82.1, 63.0], [82.2, 64.0], [82.3, 64.0], [82.4, 64.0], [82.5, 64.0], [82.6, 64.0], [82.7, 64.0], [82.8, 64.0], [82.9, 64.0], [83.0, 65.0], [83.1, 65.0], [83.2, 65.0], [83.3, 65.0], [83.4, 65.0], [83.5, 65.0], [83.6, 65.0], [83.7, 65.0], [83.8, 66.0], [83.9, 66.0], [84.0, 66.0], [84.1, 66.0], [84.2, 66.0], [84.3, 66.0], [84.4, 66.0], [84.5, 66.0], [84.6, 67.0], [84.7, 67.0], [84.8, 67.0], [84.9, 67.0], [85.0, 67.0], [85.1, 67.0], [85.2, 67.0], [85.3, 67.0], [85.4, 68.0], [85.5, 68.0], [85.6, 68.0], [85.7, 68.0], [85.8, 68.0], [85.9, 68.0], [86.0, 68.0], [86.1, 69.0], [86.2, 69.0], [86.3, 69.0], [86.4, 69.0], [86.5, 69.0], [86.6, 69.0], [86.7, 70.0], [86.8, 70.0], [86.9, 70.0], [87.0, 70.0], [87.1, 70.0], [87.2, 71.0], [87.3, 71.0], [87.4, 71.0], [87.5, 71.0], [87.6, 71.0], [87.7, 71.0], [87.8, 72.0], [87.9, 72.0], [88.0, 72.0], [88.1, 72.0], [88.2, 72.0], [88.3, 72.0], [88.4, 72.0], [88.5, 73.0], [88.6, 73.0], [88.7, 73.0], [88.8, 73.0], [88.9, 73.0], [89.0, 74.0], [89.1, 74.0], [89.2, 74.0], [89.3, 74.0], [89.4, 74.0], [89.5, 75.0], [89.6, 75.0], [89.7, 75.0], [89.8, 75.0], [89.9, 75.0], [90.0, 76.0], [90.1, 76.0], [90.2, 76.0], [90.3, 76.0], [90.4, 76.0], [90.5, 77.0], [90.6, 77.0], [90.7, 77.0], [90.8, 77.0], [90.9, 78.0], [91.0, 78.0], [91.1, 78.0], [91.2, 78.0], [91.3, 79.0], [91.4, 79.0], [91.5, 79.0], [91.6, 79.0], [91.7, 80.0], [91.8, 80.0], [91.9, 80.0], [92.0, 80.0], [92.1, 80.0], [92.2, 81.0], [92.3, 81.0], [92.4, 81.0], [92.5, 81.0], [92.6, 82.0], [92.7, 82.0], [92.8, 82.0], [92.9, 83.0], [93.0, 83.0], [93.1, 83.0], [93.2, 84.0], [93.3, 84.0], [93.4, 84.0], [93.5, 85.0], [93.6, 85.0], [93.7, 85.0], [93.8, 86.0], [93.9, 86.0], [94.0, 86.0], [94.1, 86.0], [94.2, 87.0], [94.3, 87.0], [94.4, 88.0], [94.5, 88.0], [94.6, 88.0], [94.7, 89.0], [94.8, 89.0], [94.9, 90.0], [95.0, 90.0], [95.1, 91.0], [95.2, 91.0], [95.3, 92.0], [95.4, 92.0], [95.5, 93.0], [95.6, 93.0], [95.7, 94.0], [95.8, 95.0], [95.9, 95.0], [96.0, 96.0], [96.1, 96.0], [96.2, 97.0], [96.3, 97.0], [96.4, 98.0], [96.5, 98.0], [96.6, 99.0], [96.7, 100.0], [96.8, 101.0], [96.9, 102.0], [97.0, 102.0], [97.1, 103.0], [97.2, 103.0], [97.3, 104.0], [97.4, 105.0], [97.5, 106.0], [97.6, 107.0], [97.7, 108.0], [97.8, 109.0], [97.9, 110.0], [98.0, 111.0], [98.1, 112.0], [98.2, 113.0], [98.3, 114.0], [98.4, 115.0], [98.5, 117.0], [98.6, 117.0], [98.7, 120.0], [98.8, 121.0], [98.9, 123.0], [99.0, 125.0], [99.1, 128.0], [99.2, 130.0], [99.3, 134.0], [99.4, 136.0], [99.5, 141.0], [99.6, 145.0], [99.7, 149.0], [99.8, 159.0], [99.9, 168.0], [100.0, 250.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 2.0, "minX": 0.0, "maxY": 9662.0, "series": [{"data": [[0.0, 9662.0], [100.0, 336.0], [200.0, 2.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 10000.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 10000.0, "series": [{"data": [[0.0, 10000.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 4.9E-324, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 5.12037037037037, "minX": 1.792731984E12, "maxY": 46.68582375478929, "series": [{"data": [[1.792731984E12, 5.12037037037037], [1.792731989E12, 46.68582375478929], [1.792731988E12, 41.50182260024302], [1.792731987E12, 32.575376884422084], [1.792731986E12, 22.315573770491806], [1.792731985E12, 12.96493688639551], [1.792731994E12, 36.476997578692504], [1.792731993E12, 40.521957340025054], [1.792731992E12, 42.59784075573549], [1.792731991E12, 44.52798053527984], [1.79273199E12, 46.0], [1.792731997E12, 6.121387283236993], [1.792731996E12, 21.48531139835487], [1.792731995E12, 30.727923627684977]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792731997E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 5.166666666666667, "minX": 1.0, "maxY": 59.2159916926272, "series": [{"data": [[2.0, 7.028571428571429], [32.0, 37.31932773109244], [33.0, 39.85321100917431], [34.0, 45.39705882352945], [35.0, 44.94964028776976], [36.0, 49.7924528301887], [37.0, 46.374999999999986], [38.0, 44.38649155722327], [39.0, 48.34722222222222], [40.0, 52.55882352941172], [41.0, 53.386554621848724], [42.0, 48.15769230769235], [43.0, 53.19912948857457], [44.0, 54.290697674418624], [45.0, 56.17647058823533], [46.0, 59.2159916926272], [47.0, 59.183811129848245], [3.0, 6.365853658536585], [4.0, 7.528301886792453], [5.0, 9.144578313253016], [6.0, 9.025], [7.0, 11.926470588235297], [8.0, 11.579710144927542], [9.0, 13.709401709401709], [10.0, 17.16363636363636], [11.0, 12.740740740740732], [12.0, 16.776470588235295], [13.0, 16.217391304347824], [14.0, 17.710843373493972], [15.0, 20.988505747126435], [16.0, 21.297297297297302], [1.0, 5.166666666666667], [17.0, 20.84782608695653], [18.0, 20.8443113772455], [19.0, 23.340740740740728], [20.0, 24.05294117647058], [21.0, 25.086614173228337], [22.0, 23.696428571428573], [23.0, 28.552631578947377], [24.0, 29.744897959183678], [25.0, 29.129629629629623], [26.0, 32.776119402985074], [27.0, 44.072398190045234], [28.0, 34.726086956521705], [29.0, 32.95652173913044], [30.0, 34.08130081300813], [31.0, 36.08173076923077]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[33.54909999999996, 42.24560000000024]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 47.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 65364.0, "minX": 1.792731984E12, "maxY": 384040.0, "series": [{"data": [[1.792731984E12, 146302.0], [1.792731989E12, 353574.0], [1.792731988E12, 371669.0], [1.792731987E12, 359682.0], [1.792731986E12, 330608.0], [1.792731985E12, 322027.0], [1.792731994E12, 372901.0], [1.792731993E12, 359613.0], [1.792731992E12, 334677.0], [1.792731991E12, 371021.0], [1.79273199E12, 352751.0], [1.792731997E12, 77789.0], [1.792731996E12, 384040.0], [1.792731995E12, 378494.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792731984E12, 122326.0], [1.792731989E12, 295835.0], [1.792731988E12, 310912.0], [1.792731987E12, 300865.0], [1.792731986E12, 276527.0], [1.792731985E12, 269381.0], [1.792731994E12, 312067.0], [1.792731993E12, 301099.0], [1.792731992E12, 279988.0], [1.792731991E12, 310512.0], [1.79273199E12, 295015.0], [1.792731997E12, 65364.0], [1.792731996E12, 321472.0], [1.792731995E12, 316685.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792731997E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 8.56481481481482, "minX": 1.792731984E12, "maxY": 59.61715749039695, "series": [{"data": [[1.792731984E12, 8.56481481481482], [1.792731989E12, 59.17752234993619], [1.792731988E12, 49.49696233292832], [1.792731987E12, 40.78391959798995], [1.792731986E12, 30.301912568306005], [1.792731985E12, 17.47685834502104], [1.792731994E12, 44.215496368038764], [1.792731993E12, 50.88833124215815], [1.792731992E12, 57.85425101214579], [1.792731991E12, 53.97323600973239], [1.79273199E12, 59.61715749039695], [1.792731997E12, 10.687861271676303], [1.792731996E12, 25.78025851938893], [1.792731995E12, 36.799522673031]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792731997E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 8.537037037037031, "minX": 1.792731984E12, "maxY": 59.6107554417414, "series": [{"data": [[1.792731984E12, 8.537037037037031], [1.792731989E12, 59.16985951468715], [1.792731988E12, 49.49331713244226], [1.792731987E12, 40.77638190954773], [1.792731986E12, 30.29781420765028], [1.792731985E12, 17.46704067321177], [1.792731994E12, 44.2094430992736], [1.792731993E12, 50.88205771643662], [1.792731992E12, 57.85020242914981], [1.792731991E12, 53.969586374695844], [1.79273199E12, 59.6107554417414], [1.792731997E12, 10.687861271676303], [1.792731996E12, 25.774383078730914], [1.792731995E12, 36.795942720763705]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792731997E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792731984E12, "maxY": 0.09876543209876554, "series": [{"data": [[1.792731984E12, 0.09876543209876554], [1.792731989E12, 0.006385696040868461], [1.792731988E12, 0.007290400972053456], [1.792731987E12, 0.008793969849246233], [1.792731986E12, 0.010928961748633878], [1.792731985E12, 0.01262272089761572], [1.792731994E12, 0.008474576271186448], [1.792731993E12, 0.0037641154328732773], [1.792731992E12, 0.0026990553306342788], [1.792731991E12, 0.0036496350364963502], [1.79273199E12, 0.001280409731113957], [1.792731997E12, 0.0], [1.792731996E12, 0.0], [1.792731995E12, 0.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792731997E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.792731984E12, "maxY": 250.0, "series": [{"data": [[1.792731984E12, 40.0], [1.792731989E12, 188.0], [1.792731988E12, 144.0], [1.792731987E12, 184.0], [1.792731986E12, 209.0], [1.792731985E12, 118.0], [1.792731994E12, 158.0], [1.792731993E12, 198.0], [1.792731992E12, 192.0], [1.792731991E12, 159.0], [1.79273199E12, 250.0], [1.792731997E12, 70.0], [1.792731996E12, 145.0], [1.792731995E12, 160.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792731984E12, 5.0], [1.792731989E12, 6.0], [1.792731988E12, 5.0], [1.792731987E12, 8.0], [1.792731986E12, 7.0], [1.792731985E12, 6.0], [1.792731994E12, 6.0], [1.792731993E12, 7.0], [1.792731992E12, 7.0], [1.792731991E12, 6.0], [1.79273199E12, 6.0], [1.792731997E12, 5.0], [1.792731996E12, 6.0], [1.792731995E12, 6.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792731984E12, 11.0], [1.792731989E12, 93.60000000000002], [1.792731988E12, 77.60000000000002], [1.792731987E12, 62.30000000000007], [1.792731986E12, 50.0], [1.792731985E12, 28.0], [1.792731994E12, 71.0], [1.792731993E12, 80.0], [1.792731992E12, 93.0], [1.792731991E12, 82.0], [1.79273199E12, 94.80000000000007], [1.792731997E12, 19.0], [1.792731996E12, 42.0], [1.792731995E12, 58.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792731984E12, 18.75], [1.792731989E12, 135.79999999999984], [1.792731988E12, 119.27999999999997], [1.792731987E12, 115.02999999999997], [1.792731986E12, 116.66999999999996], [1.792731985E12, 53.30000000000007], [1.792731994E12, 117.73000000000002], [1.792731993E12, 128.03999999999996], [1.792731992E12, 161.16000000000008], [1.792731991E12, 132.8499999999999], [1.79273199E12, 137.0799999999997], [1.792731997E12, 49.279999999999745], [1.792731996E12, 89.96000000000004], [1.792731995E12, 90.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792731984E12, 8.0], [1.792731989E12, 57.0], [1.792731988E12, 48.0], [1.792731987E12, 39.0], [1.792731986E12, 24.5], [1.792731985E12, 15.0], [1.792731994E12, 42.0], [1.792731993E12, 48.0], [1.792731992E12, 52.0], [1.792731991E12, 51.0], [1.79273199E12, 56.0], [1.792731997E12, 8.0], [1.792731996E12, 22.0], [1.792731995E12, 34.5]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792731984E12, 14.0], [1.792731989E12, 107.79999999999995], [1.792731988E12, 91.0], [1.792731987E12, 74.14999999999998], [1.792731986E12, 74.35000000000002], [1.792731985E12, 35.299999999999955], [1.792731994E12, 81.0], [1.792731993E12, 95.0], [1.792731992E12, 116.89999999999998], [1.792731991E12, 97.0], [1.79273199E12, 103.89999999999998], [1.792731997E12, 24.299999999999983], [1.792731996E12, 51.0], [1.792731995E12, 68.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792731997E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 8.0, "minX": 173.0, "maxY": 57.0, "series": [{"data": [[173.0, 8.0], [713.0, 15.0], [732.0, 24.5], [741.0, 52.0], [796.0, 39.0], [783.0, 57.0], [781.0, 56.0], [797.0, 48.0], [823.0, 48.0], [822.0, 51.0], [826.0, 42.0], [838.0, 34.5], [851.0, 22.0], [324.0, 8.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 851.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 8.0, "minX": 173.0, "maxY": 57.0, "series": [{"data": [[173.0, 8.0], [713.0, 15.0], [732.0, 24.5], [741.0, 52.0], [796.0, 39.0], [783.0, 57.0], [781.0, 56.0], [797.0, 48.0], [823.0, 48.0], [822.0, 51.0], [826.0, 41.5], [838.0, 34.0], [851.0, 22.0], [324.0, 8.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 851.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 160.0, "minX": 1.792731984E12, "maxY": 837.0, "series": [{"data": [[1.792731984E12, 332.0], [1.792731989E12, 784.0], [1.792731988E12, 830.0], [1.792731987E12, 806.0], [1.792731986E12, 743.0], [1.792731985E12, 722.0], [1.792731994E12, 822.0], [1.792731993E12, 794.0], [1.792731992E12, 739.0], [1.792731991E12, 819.0], [1.79273199E12, 781.0], [1.792731997E12, 160.0], [1.792731996E12, 837.0], [1.792731995E12, 831.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792731997E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 173.0, "minX": 1.792731984E12, "maxY": 851.0, "series": [{"data": [[1.792731984E12, 324.0], [1.792731989E12, 783.0], [1.792731988E12, 823.0], [1.792731987E12, 796.0], [1.792731986E12, 732.0], [1.792731985E12, 713.0], [1.792731994E12, 826.0], [1.792731993E12, 797.0], [1.792731992E12, 741.0], [1.792731991E12, 822.0], [1.79273199E12, 781.0], [1.792731997E12, 173.0], [1.792731996E12, 851.0], [1.792731995E12, 838.0]], "isOverall": false, "label": "201", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792731997E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 173.0, "minX": 1.792731984E12, "maxY": 851.0, "series": [{"data": [[1.792731984E12, 324.0], [1.792731989E12, 783.0], [1.792731988E12, 823.0], [1.792731987E12, 796.0], [1.792731986E12, 732.0], [1.792731985E12, 713.0], [1.792731994E12, 826.0], [1.792731993E12, 797.0], [1.792731992E12, 741.0], [1.792731991E12, 822.0], [1.79273199E12, 781.0], [1.792731997E12, 173.0], [1.792731996E12, 851.0], [1.792731995E12, 838.0]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792731997E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 173.0, "minX": 1.792731984E12, "maxY": 851.0, "series": [{"data": [[1.792731984E12, 324.0], [1.792731989E12, 783.0], [1.792731988E12, 823.0], [1.792731987E12, 796.0], [1.792731986E12, 732.0], [1.792731985E12, 713.0], [1.792731994E12, 826.0], [1.792731993E12, 797.0], [1.792731992E12, 741.0], [1.792731991E12, 822.0], [1.79273199E12, 781.0], [1.792731997E12, 173.0], [1.792731996E12, 851.0], [1.792731995E12, 838.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792731997E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}


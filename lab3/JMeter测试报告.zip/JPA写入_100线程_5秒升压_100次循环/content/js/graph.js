/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 5.0, "minX": 0.0, "maxY": 335.0, "series": [{"data": [[0.0, 5.0], [0.1, 6.0], [0.2, 6.0], [0.3, 7.0], [0.4, 7.0], [0.5, 7.0], [0.6, 7.0], [0.7, 7.0], [0.8, 8.0], [0.9, 8.0], [1.0, 8.0], [1.1, 8.0], [1.2, 8.0], [1.3, 8.0], [1.4, 8.0], [1.5, 8.0], [1.6, 8.0], [1.7, 9.0], [1.8, 9.0], [1.9, 9.0], [2.0, 9.0], [2.1, 9.0], [2.2, 9.0], [2.3, 9.0], [2.4, 9.0], [2.5, 9.0], [2.6, 9.0], [2.7, 9.0], [2.8, 10.0], [2.9, 10.0], [3.0, 10.0], [3.1, 10.0], [3.2, 10.0], [3.3, 10.0], [3.4, 10.0], [3.5, 10.0], [3.6, 10.0], [3.7, 11.0], [3.8, 11.0], [3.9, 11.0], [4.0, 11.0], [4.1, 11.0], [4.2, 11.0], [4.3, 11.0], [4.4, 11.0], [4.5, 11.0], [4.6, 12.0], [4.7, 12.0], [4.8, 12.0], [4.9, 12.0], [5.0, 12.0], [5.1, 12.0], [5.2, 12.0], [5.3, 13.0], [5.4, 13.0], [5.5, 13.0], [5.6, 13.0], [5.7, 13.0], [5.8, 13.0], [5.9, 13.0], [6.0, 14.0], [6.1, 14.0], [6.2, 14.0], [6.3, 14.0], [6.4, 14.0], [6.5, 15.0], [6.6, 15.0], [6.7, 15.0], [6.8, 15.0], [6.9, 15.0], [7.0, 15.0], [7.1, 16.0], [7.2, 16.0], [7.3, 16.0], [7.4, 16.0], [7.5, 17.0], [7.6, 17.0], [7.7, 17.0], [7.8, 17.0], [7.9, 18.0], [8.0, 18.0], [8.1, 18.0], [8.2, 18.0], [8.3, 18.0], [8.4, 19.0], [8.5, 19.0], [8.6, 19.0], [8.7, 19.0], [8.8, 19.0], [8.9, 19.0], [9.0, 20.0], [9.1, 20.0], [9.2, 20.0], [9.3, 20.0], [9.4, 20.0], [9.5, 21.0], [9.6, 21.0], [9.7, 21.0], [9.8, 21.0], [9.9, 21.0], [10.0, 21.0], [10.1, 21.0], [10.2, 22.0], [10.3, 22.0], [10.4, 22.0], [10.5, 22.0], [10.6, 22.0], [10.7, 23.0], [10.8, 23.0], [10.9, 23.0], [11.0, 23.0], [11.1, 23.0], [11.2, 24.0], [11.3, 24.0], [11.4, 24.0], [11.5, 24.0], [11.6, 24.0], [11.7, 24.0], [11.8, 24.0], [11.9, 25.0], [12.0, 25.0], [12.1, 25.0], [12.2, 25.0], [12.3, 25.0], [12.4, 26.0], [12.5, 26.0], [12.6, 26.0], [12.7, 26.0], [12.8, 26.0], [12.9, 26.0], [13.0, 27.0], [13.1, 27.0], [13.2, 27.0], [13.3, 27.0], [13.4, 27.0], [13.5, 27.0], [13.6, 27.0], [13.7, 28.0], [13.8, 28.0], [13.9, 28.0], [14.0, 28.0], [14.1, 28.0], [14.2, 29.0], [14.3, 29.0], [14.4, 29.0], [14.5, 29.0], [14.6, 29.0], [14.7, 29.0], [14.8, 30.0], [14.9, 30.0], [15.0, 30.0], [15.1, 30.0], [15.2, 30.0], [15.3, 30.0], [15.4, 31.0], [15.5, 31.0], [15.6, 31.0], [15.7, 31.0], [15.8, 31.0], [15.9, 31.0], [16.0, 32.0], [16.1, 32.0], [16.2, 32.0], [16.3, 32.0], [16.4, 32.0], [16.5, 32.0], [16.6, 32.0], [16.7, 33.0], [16.8, 33.0], [16.9, 33.0], [17.0, 33.0], [17.1, 33.0], [17.2, 33.0], [17.3, 34.0], [17.4, 34.0], [17.5, 34.0], [17.6, 34.0], [17.7, 34.0], [17.8, 34.0], [17.9, 35.0], [18.0, 35.0], [18.1, 35.0], [18.2, 35.0], [18.3, 35.0], [18.4, 35.0], [18.5, 35.0], [18.6, 36.0], [18.7, 36.0], [18.8, 36.0], [18.9, 36.0], [19.0, 36.0], [19.1, 36.0], [19.2, 36.0], [19.3, 37.0], [19.4, 37.0], [19.5, 37.0], [19.6, 37.0], [19.7, 37.0], [19.8, 37.0], [19.9, 37.0], [20.0, 38.0], [20.1, 38.0], [20.2, 38.0], [20.3, 38.0], [20.4, 38.0], [20.5, 38.0], [20.6, 38.0], [20.7, 38.0], [20.8, 39.0], [20.9, 39.0], [21.0, 39.0], [21.1, 39.0], [21.2, 39.0], [21.3, 39.0], [21.4, 39.0], [21.5, 39.0], [21.6, 40.0], [21.7, 40.0], [21.8, 40.0], [21.9, 40.0], [22.0, 40.0], [22.1, 40.0], [22.2, 40.0], [22.3, 40.0], [22.4, 41.0], [22.5, 41.0], [22.6, 41.0], [22.7, 41.0], [22.8, 41.0], [22.9, 41.0], [23.0, 41.0], [23.1, 41.0], [23.2, 41.0], [23.3, 42.0], [23.4, 42.0], [23.5, 42.0], [23.6, 42.0], [23.7, 42.0], [23.8, 42.0], [23.9, 42.0], [24.0, 42.0], [24.1, 42.0], [24.2, 43.0], [24.3, 43.0], [24.4, 43.0], [24.5, 43.0], [24.6, 43.0], [24.7, 43.0], [24.8, 43.0], [24.9, 43.0], [25.0, 44.0], [25.1, 44.0], [25.2, 44.0], [25.3, 44.0], [25.4, 44.0], [25.5, 44.0], [25.6, 44.0], [25.7, 45.0], [25.8, 45.0], [25.9, 45.0], [26.0, 45.0], [26.1, 45.0], [26.2, 45.0], [26.3, 46.0], [26.4, 46.0], [26.5, 46.0], [26.6, 46.0], [26.7, 46.0], [26.8, 46.0], [26.9, 46.0], [27.0, 47.0], [27.1, 47.0], [27.2, 47.0], [27.3, 47.0], [27.4, 47.0], [27.5, 47.0], [27.6, 47.0], [27.7, 48.0], [27.8, 48.0], [27.9, 48.0], [28.0, 48.0], [28.1, 48.0], [28.2, 48.0], [28.3, 48.0], [28.4, 49.0], [28.5, 49.0], [28.6, 49.0], [28.7, 49.0], [28.8, 49.0], [28.9, 49.0], [29.0, 50.0], [29.1, 50.0], [29.2, 50.0], [29.3, 50.0], [29.4, 50.0], [29.5, 50.0], [29.6, 50.0], [29.7, 51.0], [29.8, 51.0], [29.9, 51.0], [30.0, 51.0], [30.1, 51.0], [30.2, 51.0], [30.3, 51.0], [30.4, 52.0], [30.5, 52.0], [30.6, 52.0], [30.7, 52.0], [30.8, 52.0], [30.9, 52.0], [31.0, 52.0], [31.1, 52.0], [31.2, 53.0], [31.3, 53.0], [31.4, 53.0], [31.5, 53.0], [31.6, 53.0], [31.7, 53.0], [31.8, 53.0], [31.9, 54.0], [32.0, 54.0], [32.1, 54.0], [32.2, 54.0], [32.3, 54.0], [32.4, 55.0], [32.5, 55.0], [32.6, 55.0], [32.7, 55.0], [32.8, 55.0], [32.9, 55.0], [33.0, 55.0], [33.1, 56.0], [33.2, 56.0], [33.3, 56.0], [33.4, 56.0], [33.5, 56.0], [33.6, 56.0], [33.7, 56.0], [33.8, 56.0], [33.9, 57.0], [34.0, 57.0], [34.1, 57.0], [34.2, 57.0], [34.3, 57.0], [34.4, 57.0], [34.5, 57.0], [34.6, 58.0], [34.7, 58.0], [34.8, 58.0], [34.9, 58.0], [35.0, 58.0], [35.1, 58.0], [35.2, 58.0], [35.3, 58.0], [35.4, 59.0], [35.5, 59.0], [35.6, 59.0], [35.7, 59.0], [35.8, 59.0], [35.9, 59.0], [36.0, 59.0], [36.1, 59.0], [36.2, 60.0], [36.3, 60.0], [36.4, 60.0], [36.5, 60.0], [36.6, 60.0], [36.7, 60.0], [36.8, 60.0], [36.9, 60.0], [37.0, 60.0], [37.1, 61.0], [37.2, 61.0], [37.3, 61.0], [37.4, 61.0], [37.5, 61.0], [37.6, 61.0], [37.7, 61.0], [37.8, 61.0], [37.9, 61.0], [38.0, 62.0], [38.1, 62.0], [38.2, 62.0], [38.3, 62.0], [38.4, 62.0], [38.5, 62.0], [38.6, 62.0], [38.7, 62.0], [38.8, 63.0], [38.9, 63.0], [39.0, 63.0], [39.1, 63.0], [39.2, 63.0], [39.3, 63.0], [39.4, 63.0], [39.5, 64.0], [39.6, 64.0], [39.7, 64.0], [39.8, 64.0], [39.9, 64.0], [40.0, 64.0], [40.1, 64.0], [40.2, 64.0], [40.3, 64.0], [40.4, 65.0], [40.5, 65.0], [40.6, 65.0], [40.7, 65.0], [40.8, 65.0], [40.9, 65.0], [41.0, 65.0], [41.1, 66.0], [41.2, 66.0], [41.3, 66.0], [41.4, 66.0], [41.5, 66.0], [41.6, 66.0], [41.7, 66.0], [41.8, 66.0], [41.9, 66.0], [42.0, 67.0], [42.1, 67.0], [42.2, 67.0], [42.3, 67.0], [42.4, 67.0], [42.5, 67.0], [42.6, 67.0], [42.7, 67.0], [42.8, 68.0], [42.9, 68.0], [43.0, 68.0], [43.1, 68.0], [43.2, 68.0], [43.3, 68.0], [43.4, 68.0], [43.5, 69.0], [43.6, 69.0], [43.7, 69.0], [43.8, 69.0], [43.9, 69.0], [44.0, 69.0], [44.1, 69.0], [44.2, 69.0], [44.3, 70.0], [44.4, 70.0], [44.5, 70.0], [44.6, 70.0], [44.7, 70.0], [44.8, 70.0], [44.9, 70.0], [45.0, 70.0], [45.1, 70.0], [45.2, 70.0], [45.3, 70.0], [45.4, 71.0], [45.5, 71.0], [45.6, 71.0], [45.7, 71.0], [45.8, 71.0], [45.9, 71.0], [46.0, 71.0], [46.1, 71.0], [46.2, 72.0], [46.3, 72.0], [46.4, 72.0], [46.5, 72.0], [46.6, 72.0], [46.7, 72.0], [46.8, 72.0], [46.9, 72.0], [47.0, 73.0], [47.1, 73.0], [47.2, 73.0], [47.3, 73.0], [47.4, 73.0], [47.5, 73.0], [47.6, 73.0], [47.7, 73.0], [47.8, 73.0], [47.9, 74.0], [48.0, 74.0], [48.1, 74.0], [48.2, 74.0], [48.3, 74.0], [48.4, 74.0], [48.5, 74.0], [48.6, 74.0], [48.7, 75.0], [48.8, 75.0], [48.9, 75.0], [49.0, 75.0], [49.1, 75.0], [49.2, 75.0], [49.3, 75.0], [49.4, 75.0], [49.5, 75.0], [49.6, 75.0], [49.7, 76.0], [49.8, 76.0], [49.9, 76.0], [50.0, 76.0], [50.1, 76.0], [50.2, 76.0], [50.3, 76.0], [50.4, 77.0], [50.5, 77.0], [50.6, 77.0], [50.7, 77.0], [50.8, 77.0], [50.9, 77.0], [51.0, 77.0], [51.1, 77.0], [51.2, 77.0], [51.3, 78.0], [51.4, 78.0], [51.5, 78.0], [51.6, 78.0], [51.7, 78.0], [51.8, 78.0], [51.9, 78.0], [52.0, 78.0], [52.1, 79.0], [52.2, 79.0], [52.3, 79.0], [52.4, 79.0], [52.5, 79.0], [52.6, 79.0], [52.7, 79.0], [52.8, 79.0], [52.9, 79.0], [53.0, 80.0], [53.1, 80.0], [53.2, 80.0], [53.3, 80.0], [53.4, 80.0], [53.5, 80.0], [53.6, 80.0], [53.7, 80.0], [53.8, 80.0], [53.9, 80.0], [54.0, 81.0], [54.1, 81.0], [54.2, 81.0], [54.3, 81.0], [54.4, 81.0], [54.5, 81.0], [54.6, 81.0], [54.7, 81.0], [54.8, 81.0], [54.9, 82.0], [55.0, 82.0], [55.1, 82.0], [55.2, 82.0], [55.3, 82.0], [55.4, 82.0], [55.5, 82.0], [55.6, 82.0], [55.7, 82.0], [55.8, 83.0], [55.9, 83.0], [56.0, 83.0], [56.1, 83.0], [56.2, 83.0], [56.3, 83.0], [56.4, 83.0], [56.5, 83.0], [56.6, 83.0], [56.7, 84.0], [56.8, 84.0], [56.9, 84.0], [57.0, 84.0], [57.1, 84.0], [57.2, 84.0], [57.3, 84.0], [57.4, 84.0], [57.5, 85.0], [57.6, 85.0], [57.7, 85.0], [57.8, 85.0], [57.9, 85.0], [58.0, 85.0], [58.1, 85.0], [58.2, 85.0], [58.3, 86.0], [58.4, 86.0], [58.5, 86.0], [58.6, 86.0], [58.7, 86.0], [58.8, 86.0], [58.9, 86.0], [59.0, 86.0], [59.1, 87.0], [59.2, 87.0], [59.3, 87.0], [59.4, 87.0], [59.5, 87.0], [59.6, 87.0], [59.7, 87.0], [59.8, 87.0], [59.9, 87.0], [60.0, 87.0], [60.1, 88.0], [60.2, 88.0], [60.3, 88.0], [60.4, 88.0], [60.5, 88.0], [60.6, 88.0], [60.7, 88.0], [60.8, 89.0], [60.9, 89.0], [61.0, 89.0], [61.1, 89.0], [61.2, 89.0], [61.3, 89.0], [61.4, 89.0], [61.5, 90.0], [61.6, 90.0], [61.7, 90.0], [61.8, 90.0], [61.9, 90.0], [62.0, 90.0], [62.1, 90.0], [62.2, 90.0], [62.3, 90.0], [62.4, 91.0], [62.5, 91.0], [62.6, 91.0], [62.7, 91.0], [62.8, 91.0], [62.9, 91.0], [63.0, 91.0], [63.1, 92.0], [63.2, 92.0], [63.3, 92.0], [63.4, 92.0], [63.5, 92.0], [63.6, 92.0], [63.7, 92.0], [63.8, 93.0], [63.9, 93.0], [64.0, 93.0], [64.1, 93.0], [64.2, 93.0], [64.3, 93.0], [64.4, 94.0], [64.5, 94.0], [64.6, 94.0], [64.7, 94.0], [64.8, 94.0], [64.9, 94.0], [65.0, 94.0], [65.1, 94.0], [65.2, 95.0], [65.3, 95.0], [65.4, 95.0], [65.5, 95.0], [65.6, 95.0], [65.7, 95.0], [65.8, 96.0], [65.9, 96.0], [66.0, 96.0], [66.1, 96.0], [66.2, 96.0], [66.3, 96.0], [66.4, 96.0], [66.5, 96.0], [66.6, 97.0], [66.7, 97.0], [66.8, 97.0], [66.9, 97.0], [67.0, 97.0], [67.1, 97.0], [67.2, 97.0], [67.3, 98.0], [67.4, 98.0], [67.5, 98.0], [67.6, 98.0], [67.7, 98.0], [67.8, 98.0], [67.9, 98.0], [68.0, 99.0], [68.1, 99.0], [68.2, 99.0], [68.3, 99.0], [68.4, 99.0], [68.5, 99.0], [68.6, 99.0], [68.7, 100.0], [68.8, 100.0], [68.9, 100.0], [69.0, 100.0], [69.1, 100.0], [69.2, 100.0], [69.3, 100.0], [69.4, 100.0], [69.5, 101.0], [69.6, 101.0], [69.7, 101.0], [69.8, 101.0], [69.9, 101.0], [70.0, 101.0], [70.1, 101.0], [70.2, 102.0], [70.3, 102.0], [70.4, 102.0], [70.5, 102.0], [70.6, 102.0], [70.7, 102.0], [70.8, 103.0], [70.9, 103.0], [71.0, 103.0], [71.1, 103.0], [71.2, 103.0], [71.3, 103.0], [71.4, 103.0], [71.5, 103.0], [71.6, 104.0], [71.7, 104.0], [71.8, 104.0], [71.9, 104.0], [72.0, 104.0], [72.1, 105.0], [72.2, 105.0], [72.3, 105.0], [72.4, 105.0], [72.5, 105.0], [72.6, 105.0], [72.7, 105.0], [72.8, 105.0], [72.9, 106.0], [73.0, 106.0], [73.1, 106.0], [73.2, 106.0], [73.3, 106.0], [73.4, 106.0], [73.5, 106.0], [73.6, 107.0], [73.7, 107.0], [73.8, 107.0], [73.9, 107.0], [74.0, 107.0], [74.1, 107.0], [74.2, 107.0], [74.3, 107.0], [74.4, 107.0], [74.5, 108.0], [74.6, 108.0], [74.7, 108.0], [74.8, 108.0], [74.9, 108.0], [75.0, 108.0], [75.1, 108.0], [75.2, 109.0], [75.3, 109.0], [75.4, 109.0], [75.5, 109.0], [75.6, 109.0], [75.7, 109.0], [75.8, 110.0], [75.9, 110.0], [76.0, 110.0], [76.1, 110.0], [76.2, 110.0], [76.3, 110.0], [76.4, 110.0], [76.5, 110.0], [76.6, 111.0], [76.7, 111.0], [76.8, 111.0], [76.9, 111.0], [77.0, 111.0], [77.1, 111.0], [77.2, 112.0], [77.3, 112.0], [77.4, 112.0], [77.5, 112.0], [77.6, 112.0], [77.7, 113.0], [77.8, 113.0], [77.9, 113.0], [78.0, 113.0], [78.1, 113.0], [78.2, 113.0], [78.3, 113.0], [78.4, 113.0], [78.5, 114.0], [78.6, 114.0], [78.7, 114.0], [78.8, 114.0], [78.9, 114.0], [79.0, 114.0], [79.1, 114.0], [79.2, 115.0], [79.3, 115.0], [79.4, 115.0], [79.5, 115.0], [79.6, 115.0], [79.7, 115.0], [79.8, 116.0], [79.9, 116.0], [80.0, 116.0], [80.1, 116.0], [80.2, 116.0], [80.3, 116.0], [80.4, 116.0], [80.5, 117.0], [80.6, 117.0], [80.7, 117.0], [80.8, 117.0], [80.9, 117.0], [81.0, 118.0], [81.1, 118.0], [81.2, 118.0], [81.3, 118.0], [81.4, 118.0], [81.5, 119.0], [81.6, 119.0], [81.7, 119.0], [81.8, 119.0], [81.9, 119.0], [82.0, 120.0], [82.1, 120.0], [82.2, 120.0], [82.3, 120.0], [82.4, 121.0], [82.5, 121.0], [82.6, 121.0], [82.7, 121.0], [82.8, 121.0], [82.9, 122.0], [83.0, 122.0], [83.1, 122.0], [83.2, 122.0], [83.3, 122.0], [83.4, 123.0], [83.5, 123.0], [83.6, 123.0], [83.7, 123.0], [83.8, 123.0], [83.9, 124.0], [84.0, 124.0], [84.1, 124.0], [84.2, 124.0], [84.3, 125.0], [84.4, 125.0], [84.5, 125.0], [84.6, 125.0], [84.7, 126.0], [84.8, 126.0], [84.9, 126.0], [85.0, 126.0], [85.1, 126.0], [85.2, 127.0], [85.3, 127.0], [85.4, 127.0], [85.5, 127.0], [85.6, 128.0], [85.7, 128.0], [85.8, 128.0], [85.9, 128.0], [86.0, 128.0], [86.1, 129.0], [86.2, 129.0], [86.3, 129.0], [86.4, 129.0], [86.5, 129.0], [86.6, 129.0], [86.7, 130.0], [86.8, 130.0], [86.9, 130.0], [87.0, 131.0], [87.1, 131.0], [87.2, 131.0], [87.3, 131.0], [87.4, 132.0], [87.5, 132.0], [87.6, 132.0], [87.7, 132.0], [87.8, 133.0], [87.9, 133.0], [88.0, 133.0], [88.1, 134.0], [88.2, 134.0], [88.3, 134.0], [88.4, 134.0], [88.5, 135.0], [88.6, 135.0], [88.7, 135.0], [88.8, 135.0], [88.9, 136.0], [89.0, 136.0], [89.1, 136.0], [89.2, 137.0], [89.3, 137.0], [89.4, 138.0], [89.5, 138.0], [89.6, 138.0], [89.7, 138.0], [89.8, 138.0], [89.9, 139.0], [90.0, 139.0], [90.1, 139.0], [90.2, 140.0], [90.3, 140.0], [90.4, 140.0], [90.5, 141.0], [90.6, 141.0], [90.7, 141.0], [90.8, 142.0], [90.9, 142.0], [91.0, 142.0], [91.1, 143.0], [91.2, 143.0], [91.3, 144.0], [91.4, 144.0], [91.5, 144.0], [91.6, 145.0], [91.7, 145.0], [91.8, 145.0], [91.9, 146.0], [92.0, 146.0], [92.1, 146.0], [92.2, 147.0], [92.3, 147.0], [92.4, 148.0], [92.5, 148.0], [92.6, 149.0], [92.7, 149.0], [92.8, 149.0], [92.9, 150.0], [93.0, 150.0], [93.1, 151.0], [93.2, 151.0], [93.3, 152.0], [93.4, 152.0], [93.5, 152.0], [93.6, 153.0], [93.7, 153.0], [93.8, 154.0], [93.9, 154.0], [94.0, 155.0], [94.1, 155.0], [94.2, 156.0], [94.3, 156.0], [94.4, 156.0], [94.5, 156.0], [94.6, 157.0], [94.7, 157.0], [94.8, 158.0], [94.9, 158.0], [95.0, 159.0], [95.1, 160.0], [95.2, 160.0], [95.3, 161.0], [95.4, 161.0], [95.5, 162.0], [95.6, 163.0], [95.7, 163.0], [95.8, 164.0], [95.9, 165.0], [96.0, 165.0], [96.1, 166.0], [96.2, 167.0], [96.3, 167.0], [96.4, 168.0], [96.5, 169.0], [96.6, 170.0], [96.7, 171.0], [96.8, 172.0], [96.9, 172.0], [97.0, 173.0], [97.1, 174.0], [97.2, 175.0], [97.3, 176.0], [97.4, 176.0], [97.5, 177.0], [97.6, 178.0], [97.7, 179.0], [97.8, 180.0], [97.9, 181.0], [98.0, 181.0], [98.1, 183.0], [98.2, 184.0], [98.3, 186.0], [98.4, 188.0], [98.5, 190.0], [98.6, 191.0], [98.7, 193.0], [98.8, 194.0], [98.9, 196.0], [99.0, 200.0], [99.1, 202.0], [99.2, 204.0], [99.3, 209.0], [99.4, 212.0], [99.5, 216.0], [99.6, 222.0], [99.7, 233.0], [99.8, 243.0], [99.9, 254.0], [100.0, 335.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 6869.0, "series": [{"data": [[0.0, 6869.0], [300.0, 1.0], [100.0, 3029.0], [200.0, 101.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 300.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 10000.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 10000.0, "series": [{"data": [[0.0, 10000.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 4.9E-324, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.79273203E12, "maxY": 88.92478421701612, "series": [{"data": [[1.792732043E12, 25.041463414634116], [1.792732032E12, 33.47759282970547], [1.792732031E12, 14.12225274725274], [1.79273203E12, 3.0], [1.792732037E12, 87.47852760736194], [1.792732036E12, 88.92478421701612], [1.792732035E12, 85.62915601023013], [1.792732034E12, 68.3754740834386], [1.792732033E12, 51.592875318066135], [1.792732042E12, 49.530712530712506], [1.792732041E12, 64.94763092269334], [1.79273204E12, 73.86643026004708], [1.792732039E12, 79.95568862275448], [1.792732038E12, 84.09296482412063]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732043E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.0, "maxY": 124.9401709401709, "series": [{"data": [[2.0, 5.0], [3.0, 21.166666666666668], [4.0, 7.625], [5.0, 7.612903225806452], [6.0, 8.219512195121952], [7.0, 9.285714285714286], [8.0, 10.023809523809526], [9.0, 13.542857142857141], [10.0, 15.972222222222221], [11.0, 14.863636363636363], [12.0, 16.632653061224495], [13.0, 16.63157894736842], [14.0, 17.060606060606062], [15.0, 24.09756097560976], [16.0, 22.461538461538456], [17.0, 18.01694915254237], [18.0, 18.77551020408163], [19.0, 22.571428571428573], [20.0, 22.622950819672138], [21.0, 27.76086956521739], [22.0, 25.671641791044774], [23.0, 26.377777777777776], [24.0, 27.350877192982455], [25.0, 26.888888888888886], [26.0, 36.191489361702146], [27.0, 32.43902439024391], [28.0, 34.31818181818183], [29.0, 32.92000000000001], [30.0, 38.306122448979586], [31.0, 35.69444444444444], [32.0, 42.60869565217392], [33.0, 40.90322580645164], [34.0, 42.11940298507466], [35.0, 40.643835616438366], [36.0, 49.59302325581395], [37.0, 49.541666666666664], [38.0, 47.921052631578945], [39.0, 47.49230769230769], [40.0, 42.260273972602754], [41.0, 47.84905660377356], [42.0, 50.051282051282044], [43.0, 57.94117647058824], [44.0, 55.47747747747746], [45.0, 52.659574468085104], [46.0, 66.01980198019804], [47.0, 49.45652173913043], [48.0, 67.73437499999997], [49.0, 59.168539325842715], [50.0, 59.08602150537635], [51.0, 66.45833333333337], [52.0, 64.9868421052632], [53.0, 67.38383838383842], [54.0, 73.16666666666664], [55.0, 65.95238095238096], [56.0, 63.295454545454554], [57.0, 69.36075949367088], [58.0, 68.63636363636363], [59.0, 83.47706422018348], [60.0, 75.85227272727272], [61.0, 81.18421052631582], [62.0, 76.21212121212122], [63.0, 74.40845070422536], [64.0, 77.67200000000001], [65.0, 80.9491525423729], [66.0, 83.13368983957218], [67.0, 84.69014084507042], [68.0, 88.02400000000004], [69.0, 84.61538461538464], [70.0, 85.8472222222222], [71.0, 83.50239234449761], [72.0, 91.30769230769234], [73.0, 82.33928571428567], [74.0, 88.64176245210739], [75.0, 92.10465116279072], [76.0, 91.84210526315793], [77.0, 96.08152173913044], [78.0, 102.14935064935068], [79.0, 96.95], [80.0, 92.60869565217395], [81.0, 92.84098939929326], [82.0, 99.22700587084151], [83.0, 102.93495934959347], [84.0, 108.1599999999999], [85.0, 106.71969696969697], [86.0, 110.92574257425746], [87.0, 101.06739526411658], [88.0, 110.27634408602147], [89.0, 107.88811188811188], [90.0, 123.50833333333337], [91.0, 124.9401709401709], [92.0, 123.7821782178218], [1.0, 6.333333333333333]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[64.03129999999979, 79.21699999999963]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 92.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 1137.0, "minX": 1.79273203E12, "maxY": 382077.0, "series": [{"data": [[1.792732043E12, 184243.0], [1.792732032E12, 352803.0], [1.792732031E12, 328947.0], [1.79273203E12, 1359.0], [1.792732037E12, 368204.0], [1.792732036E12, 366208.0], [1.792732035E12, 353311.0], [1.792732034E12, 357369.0], [1.792732033E12, 355024.0], [1.792732042E12, 367026.0], [1.792732041E12, 361979.0], [1.79273204E12, 382077.0], [1.792732039E12, 376909.0], [1.792732038E12, 359440.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792732043E12, 154947.0], [1.792732032E12, 295009.0], [1.792732031E12, 275075.0], [1.79273203E12, 1137.0], [1.792732037E12, 307923.0], [1.792732036E12, 306310.0], [1.792732035E12, 295501.0], [1.792732034E12, 298893.0], [1.792732033E12, 296976.0], [1.792732042E12, 307428.0], [1.792732041E12, 303008.0], [1.79273204E12, 319647.0], [1.792732039E12, 315264.0], [1.792732038E12, 300681.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732043E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 17.81043956043957, "minX": 1.79273203E12, "maxY": 110.13686806411845, "series": [{"data": [[1.792732043E12, 30.319512195121938], [1.792732032E12, 41.439180537772074], [1.792732031E12, 17.81043956043957], [1.79273203E12, 34.666666666666664], [1.792732037E12, 108.67730061349697], [1.792732036E12, 110.13686806411845], [1.792732035E12, 106.43989769820976], [1.792732034E12, 84.25031605562582], [1.792732033E12, 64.21501272264629], [1.792732042E12, 61.49385749385761], [1.792732041E12, 82.91770573566079], [1.79273204E12, 86.725768321513], [1.792732039E12, 97.47544910179634], [1.792732038E12, 106.46105527638193]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732043E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 17.79670329670331, "minX": 1.79273203E12, "maxY": 110.13316892725027, "series": [{"data": [[1.792732043E12, 30.30975609756096], [1.792732032E12, 41.431498079385406], [1.792732031E12, 17.79670329670331], [1.79273203E12, 32.333333333333336], [1.792732037E12, 108.66871165644172], [1.792732036E12, 110.13316892725027], [1.792732035E12, 106.4335038363172], [1.792732034E12, 84.24652338811634], [1.792732033E12, 64.20992366412212], [1.792732042E12, 61.48771498771509], [1.792732041E12, 82.9164588528677], [1.79273204E12, 86.72222222222229], [1.792732039E12, 97.47305389221557], [1.792732038E12, 106.45979899497486]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732043E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.79273203E12, "maxY": 20.0, "series": [{"data": [[1.792732043E12, 0.0], [1.792732032E12, 0.014084507042253544], [1.792732031E12, 0.02197802197802199], [1.79273203E12, 20.0], [1.792732037E12, 0.0], [1.792732036E12, 0.0], [1.792732035E12, 0.015345268542199487], [1.792732034E12, 0.012642225031605558], [1.792732033E12, 0.015267175572519076], [1.792732042E12, 0.0], [1.792732041E12, 0.0], [1.79273204E12, 0.0], [1.792732039E12, 0.0], [1.792732038E12, 0.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732043E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.79273203E12, "maxY": 335.0, "series": [{"data": [[1.792732043E12, 143.0], [1.792732032E12, 242.0], [1.792732031E12, 115.0], [1.79273203E12, 37.0], [1.792732037E12, 253.0], [1.792732036E12, 335.0], [1.792732035E12, 276.0], [1.792732034E12, 203.0], [1.792732033E12, 190.0], [1.792732042E12, 259.0], [1.792732041E12, 266.0], [1.79273204E12, 211.0], [1.792732039E12, 237.0], [1.792732038E12, 295.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792732043E12, 5.0], [1.792732032E12, 7.0], [1.792732031E12, 5.0], [1.79273203E12, 33.0], [1.792732037E12, 8.0], [1.792732036E12, 7.0], [1.792732035E12, 13.0], [1.792732034E12, 8.0], [1.792732033E12, 8.0], [1.792732042E12, 6.0], [1.792732041E12, 7.0], [1.79273204E12, 7.0], [1.792732039E12, 6.0], [1.792732038E12, 11.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792732043E12, 57.900000000000034], [1.792732032E12, 67.0], [1.792732031E12, 32.0], [1.79273203E12, 37.0], [1.792732037E12, 157.0], [1.792732036E12, 180.80000000000007], [1.792732035E12, 161.70000000000005], [1.792732034E12, 128.0], [1.792732033E12, 99.0], [1.792732042E12, 100.0], [1.792732041E12, 132.70000000000005], [1.79273204E12, 129.0], [1.792732039E12, 148.39999999999998], [1.792732038E12, 161.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792732043E12, 108.67999999999984], [1.792732032E12, 105.17999999999995], [1.792732031E12, 56.42000000000007], [1.79273203E12, 37.0], [1.792732037E12, 215.0400000000002], [1.792732036E12, 251.64], [1.792732035E12, 206.67999999999984], [1.792732034E12, 174.72000000000037], [1.792732033E12, 153.13], [1.792732042E12, 166.70000000000005], [1.792732041E12, 183.91000000000008], [1.79273204E12, 168.23999999999978], [1.792732039E12, 201.55999999999995], [1.792732038E12, 212.23999999999978]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792732043E12, 26.0], [1.792732032E12, 39.0], [1.792732031E12, 15.0], [1.79273203E12, 34.0], [1.792732037E12, 108.0], [1.792732036E12, 105.0], [1.792732035E12, 105.0], [1.792732034E12, 82.0], [1.792732033E12, 62.0], [1.792732042E12, 58.0], [1.792732041E12, 79.0], [1.79273204E12, 85.0], [1.792732039E12, 97.0], [1.792732038E12, 104.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792732043E12, 73.0], [1.792732032E12, 78.0], [1.792732031E12, 38.0], [1.79273203E12, 37.0], [1.792732037E12, 173.39999999999986], [1.792732036E12, 202.39999999999998], [1.792732035E12, 175.0], [1.792732034E12, 143.0], [1.792732033E12, 117.0], [1.792732042E12, 117.5], [1.792732041E12, 152.69999999999982], [1.79273204E12, 141.64999999999998], [1.792732039E12, 162.19999999999993], [1.792732038E12, 176.0]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732043E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 15.0, "minX": 3.0, "maxY": 108.0, "series": [{"data": [[728.0, 15.0], [3.0, 34.0], [781.0, 39.0], [786.0, 62.0], [791.0, 82.0], [782.0, 105.0], [796.0, 104.0], [811.0, 105.0], [815.0, 108.0], [802.0, 79.0], [814.0, 58.0], [835.0, 97.0], [846.0, 85.0], [410.0, 26.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 846.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 15.0, "minX": 3.0, "maxY": 108.0, "series": [{"data": [[728.0, 15.0], [3.0, 32.0], [781.0, 39.0], [786.0, 62.0], [791.0, 82.0], [782.0, 105.0], [796.0, 104.0], [811.0, 105.0], [815.0, 108.0], [802.0, 79.0], [814.0, 58.0], [835.0, 97.0], [846.0, 85.0], [410.0, 26.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 846.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.79273203E12, "maxY": 839.0, "series": [{"data": [[1.792732043E12, 374.0], [1.792732032E12, 801.0], [1.792732031E12, 749.0], [1.79273203E12, 5.0], [1.792732037E12, 814.0], [1.792732036E12, 807.0], [1.792732035E12, 797.0], [1.792732034E12, 809.0], [1.792732033E12, 802.0], [1.792732042E12, 792.0], [1.792732041E12, 790.0], [1.79273204E12, 839.0], [1.792732039E12, 830.0], [1.792732038E12, 791.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732043E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.79273203E12, "maxY": 846.0, "series": [{"data": [[1.792732043E12, 410.0], [1.792732032E12, 781.0], [1.792732031E12, 728.0], [1.79273203E12, 3.0], [1.792732037E12, 815.0], [1.792732036E12, 811.0], [1.792732035E12, 782.0], [1.792732034E12, 791.0], [1.792732033E12, 786.0], [1.792732042E12, 814.0], [1.792732041E12, 802.0], [1.79273204E12, 846.0], [1.792732039E12, 835.0], [1.792732038E12, 796.0]], "isOverall": false, "label": "201", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732043E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.79273203E12, "maxY": 846.0, "series": [{"data": [[1.792732043E12, 410.0], [1.792732032E12, 781.0], [1.792732031E12, 728.0], [1.79273203E12, 3.0], [1.792732037E12, 815.0], [1.792732036E12, 811.0], [1.792732035E12, 782.0], [1.792732034E12, 791.0], [1.792732033E12, 786.0], [1.792732042E12, 814.0], [1.792732041E12, 802.0], [1.79273204E12, 846.0], [1.792732039E12, 835.0], [1.792732038E12, 796.0]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732043E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 3.0, "minX": 1.79273203E12, "maxY": 846.0, "series": [{"data": [[1.792732043E12, 410.0], [1.792732032E12, 781.0], [1.792732031E12, 728.0], [1.79273203E12, 3.0], [1.792732037E12, 815.0], [1.792732036E12, 811.0], [1.792732035E12, 782.0], [1.792732034E12, 791.0], [1.792732033E12, 786.0], [1.792732042E12, 814.0], [1.792732041E12, 802.0], [1.79273204E12, 846.0], [1.792732039E12, 835.0], [1.792732038E12, 796.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732043E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}


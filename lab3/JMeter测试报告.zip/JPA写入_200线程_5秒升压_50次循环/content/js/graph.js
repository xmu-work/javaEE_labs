/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 5.0, "minX": 0.0, "maxY": 598.0, "series": [{"data": [[0.0, 5.0], [0.1, 8.0], [0.2, 9.0], [0.3, 9.0], [0.4, 9.0], [0.5, 10.0], [0.6, 10.0], [0.7, 10.0], [0.8, 11.0], [0.9, 11.0], [1.0, 11.0], [1.1, 12.0], [1.2, 12.0], [1.3, 12.0], [1.4, 12.0], [1.5, 12.0], [1.6, 12.0], [1.7, 13.0], [1.8, 13.0], [1.9, 14.0], [2.0, 14.0], [2.1, 14.0], [2.2, 14.0], [2.3, 15.0], [2.4, 15.0], [2.5, 15.0], [2.6, 15.0], [2.7, 16.0], [2.8, 16.0], [2.9, 16.0], [3.0, 17.0], [3.1, 17.0], [3.2, 18.0], [3.3, 18.0], [3.4, 18.0], [3.5, 19.0], [3.6, 19.0], [3.7, 19.0], [3.8, 20.0], [3.9, 20.0], [4.0, 20.0], [4.1, 21.0], [4.2, 21.0], [4.3, 22.0], [4.4, 22.0], [4.5, 23.0], [4.6, 23.0], [4.7, 24.0], [4.8, 24.0], [4.9, 24.0], [5.0, 25.0], [5.1, 25.0], [5.2, 25.0], [5.3, 26.0], [5.4, 26.0], [5.5, 27.0], [5.6, 27.0], [5.7, 28.0], [5.8, 28.0], [5.9, 28.0], [6.0, 29.0], [6.1, 29.0], [6.2, 30.0], [6.3, 30.0], [6.4, 30.0], [6.5, 31.0], [6.6, 31.0], [6.7, 31.0], [6.8, 32.0], [6.9, 32.0], [7.0, 32.0], [7.1, 33.0], [7.2, 33.0], [7.3, 33.0], [7.4, 34.0], [7.5, 34.0], [7.6, 35.0], [7.7, 35.0], [7.8, 35.0], [7.9, 36.0], [8.0, 36.0], [8.1, 37.0], [8.2, 37.0], [8.3, 37.0], [8.4, 38.0], [8.5, 38.0], [8.6, 38.0], [8.7, 39.0], [8.8, 39.0], [8.9, 39.0], [9.0, 40.0], [9.1, 40.0], [9.2, 41.0], [9.3, 41.0], [9.4, 41.0], [9.5, 42.0], [9.6, 42.0], [9.7, 43.0], [9.8, 43.0], [9.9, 44.0], [10.0, 44.0], [10.1, 44.0], [10.2, 45.0], [10.3, 45.0], [10.4, 45.0], [10.5, 45.0], [10.6, 46.0], [10.7, 46.0], [10.8, 46.0], [10.9, 47.0], [11.0, 47.0], [11.1, 47.0], [11.2, 48.0], [11.3, 48.0], [11.4, 48.0], [11.5, 49.0], [11.6, 49.0], [11.7, 50.0], [11.8, 50.0], [11.9, 50.0], [12.0, 51.0], [12.1, 51.0], [12.2, 52.0], [12.3, 52.0], [12.4, 52.0], [12.5, 53.0], [12.6, 53.0], [12.7, 54.0], [12.8, 54.0], [12.9, 54.0], [13.0, 54.0], [13.1, 55.0], [13.2, 55.0], [13.3, 56.0], [13.4, 56.0], [13.5, 56.0], [13.6, 56.0], [13.7, 57.0], [13.8, 57.0], [13.9, 57.0], [14.0, 58.0], [14.1, 58.0], [14.2, 59.0], [14.3, 59.0], [14.4, 59.0], [14.5, 59.0], [14.6, 60.0], [14.7, 60.0], [14.8, 60.0], [14.9, 60.0], [15.0, 61.0], [15.1, 61.0], [15.2, 61.0], [15.3, 61.0], [15.4, 62.0], [15.5, 62.0], [15.6, 62.0], [15.7, 62.0], [15.8, 63.0], [15.9, 63.0], [16.0, 63.0], [16.1, 64.0], [16.2, 64.0], [16.3, 64.0], [16.4, 64.0], [16.5, 65.0], [16.6, 65.0], [16.7, 65.0], [16.8, 65.0], [16.9, 66.0], [17.0, 66.0], [17.1, 66.0], [17.2, 67.0], [17.3, 67.0], [17.4, 67.0], [17.5, 68.0], [17.6, 68.0], [17.7, 68.0], [17.8, 68.0], [17.9, 69.0], [18.0, 69.0], [18.1, 69.0], [18.2, 69.0], [18.3, 70.0], [18.4, 70.0], [18.5, 71.0], [18.6, 71.0], [18.7, 71.0], [18.8, 71.0], [18.9, 72.0], [19.0, 72.0], [19.1, 72.0], [19.2, 73.0], [19.3, 73.0], [19.4, 74.0], [19.5, 74.0], [19.6, 74.0], [19.7, 75.0], [19.8, 75.0], [19.9, 76.0], [20.0, 76.0], [20.1, 76.0], [20.2, 77.0], [20.3, 77.0], [20.4, 77.0], [20.5, 78.0], [20.6, 78.0], [20.7, 79.0], [20.8, 79.0], [20.9, 79.0], [21.0, 80.0], [21.1, 80.0], [21.2, 80.0], [21.3, 81.0], [21.4, 81.0], [21.5, 81.0], [21.6, 82.0], [21.7, 82.0], [21.8, 82.0], [21.9, 82.0], [22.0, 82.0], [22.1, 83.0], [22.2, 83.0], [22.3, 83.0], [22.4, 83.0], [22.5, 84.0], [22.6, 84.0], [22.7, 84.0], [22.8, 85.0], [22.9, 85.0], [23.0, 85.0], [23.1, 85.0], [23.2, 86.0], [23.3, 86.0], [23.4, 86.0], [23.5, 86.0], [23.6, 87.0], [23.7, 87.0], [23.8, 87.0], [23.9, 88.0], [24.0, 88.0], [24.1, 88.0], [24.2, 89.0], [24.3, 89.0], [24.4, 89.0], [24.5, 90.0], [24.6, 90.0], [24.7, 90.0], [24.8, 90.0], [24.9, 91.0], [25.0, 91.0], [25.1, 92.0], [25.2, 92.0], [25.3, 92.0], [25.4, 92.0], [25.5, 93.0], [25.6, 93.0], [25.7, 93.0], [25.8, 94.0], [25.9, 94.0], [26.0, 94.0], [26.1, 94.0], [26.2, 95.0], [26.3, 95.0], [26.4, 95.0], [26.5, 95.0], [26.6, 95.0], [26.7, 96.0], [26.8, 96.0], [26.9, 96.0], [27.0, 96.0], [27.1, 97.0], [27.2, 97.0], [27.3, 97.0], [27.4, 97.0], [27.5, 98.0], [27.6, 98.0], [27.7, 98.0], [27.8, 99.0], [27.9, 99.0], [28.0, 99.0], [28.1, 99.0], [28.2, 100.0], [28.3, 100.0], [28.4, 100.0], [28.5, 101.0], [28.6, 101.0], [28.7, 101.0], [28.8, 101.0], [28.9, 102.0], [29.0, 102.0], [29.1, 102.0], [29.2, 103.0], [29.3, 103.0], [29.4, 103.0], [29.5, 103.0], [29.6, 104.0], [29.7, 104.0], [29.8, 104.0], [29.9, 104.0], [30.0, 105.0], [30.1, 105.0], [30.2, 105.0], [30.3, 106.0], [30.4, 106.0], [30.5, 106.0], [30.6, 106.0], [30.7, 107.0], [30.8, 107.0], [30.9, 107.0], [31.0, 108.0], [31.1, 108.0], [31.2, 108.0], [31.3, 109.0], [31.4, 109.0], [31.5, 109.0], [31.6, 110.0], [31.7, 110.0], [31.8, 110.0], [31.9, 110.0], [32.0, 111.0], [32.1, 111.0], [32.2, 111.0], [32.3, 111.0], [32.4, 112.0], [32.5, 112.0], [32.6, 112.0], [32.7, 113.0], [32.8, 113.0], [32.9, 113.0], [33.0, 113.0], [33.1, 114.0], [33.2, 114.0], [33.3, 114.0], [33.4, 115.0], [33.5, 115.0], [33.6, 115.0], [33.7, 116.0], [33.8, 116.0], [33.9, 116.0], [34.0, 116.0], [34.1, 116.0], [34.2, 117.0], [34.3, 117.0], [34.4, 117.0], [34.5, 117.0], [34.6, 118.0], [34.7, 118.0], [34.8, 118.0], [34.9, 119.0], [35.0, 119.0], [35.1, 119.0], [35.2, 119.0], [35.3, 119.0], [35.4, 120.0], [35.5, 120.0], [35.6, 120.0], [35.7, 120.0], [35.8, 121.0], [35.9, 121.0], [36.0, 121.0], [36.1, 121.0], [36.2, 122.0], [36.3, 122.0], [36.4, 122.0], [36.5, 122.0], [36.6, 122.0], [36.7, 123.0], [36.8, 123.0], [36.9, 123.0], [37.0, 124.0], [37.1, 124.0], [37.2, 124.0], [37.3, 124.0], [37.4, 125.0], [37.5, 125.0], [37.6, 125.0], [37.7, 125.0], [37.8, 125.0], [37.9, 126.0], [38.0, 126.0], [38.1, 127.0], [38.2, 127.0], [38.3, 127.0], [38.4, 127.0], [38.5, 127.0], [38.6, 128.0], [38.7, 128.0], [38.8, 128.0], [38.9, 128.0], [39.0, 129.0], [39.1, 129.0], [39.2, 129.0], [39.3, 129.0], [39.4, 130.0], [39.5, 130.0], [39.6, 130.0], [39.7, 130.0], [39.8, 131.0], [39.9, 131.0], [40.0, 131.0], [40.1, 131.0], [40.2, 132.0], [40.3, 132.0], [40.4, 132.0], [40.5, 132.0], [40.6, 133.0], [40.7, 133.0], [40.8, 133.0], [40.9, 133.0], [41.0, 134.0], [41.1, 134.0], [41.2, 134.0], [41.3, 134.0], [41.4, 135.0], [41.5, 135.0], [41.6, 135.0], [41.7, 135.0], [41.8, 136.0], [41.9, 136.0], [42.0, 136.0], [42.1, 136.0], [42.2, 136.0], [42.3, 137.0], [42.4, 137.0], [42.5, 137.0], [42.6, 137.0], [42.7, 138.0], [42.8, 138.0], [42.9, 138.0], [43.0, 138.0], [43.1, 138.0], [43.2, 139.0], [43.3, 139.0], [43.4, 139.0], [43.5, 140.0], [43.6, 140.0], [43.7, 140.0], [43.8, 140.0], [43.9, 140.0], [44.0, 141.0], [44.1, 141.0], [44.2, 141.0], [44.3, 141.0], [44.4, 141.0], [44.5, 142.0], [44.6, 142.0], [44.7, 142.0], [44.8, 143.0], [44.9, 143.0], [45.0, 143.0], [45.1, 143.0], [45.2, 144.0], [45.3, 144.0], [45.4, 144.0], [45.5, 144.0], [45.6, 144.0], [45.7, 145.0], [45.8, 145.0], [45.9, 145.0], [46.0, 146.0], [46.1, 146.0], [46.2, 146.0], [46.3, 146.0], [46.4, 147.0], [46.5, 147.0], [46.6, 147.0], [46.7, 148.0], [46.8, 148.0], [46.9, 148.0], [47.0, 148.0], [47.1, 148.0], [47.2, 149.0], [47.3, 149.0], [47.4, 149.0], [47.5, 149.0], [47.6, 150.0], [47.7, 150.0], [47.8, 150.0], [47.9, 150.0], [48.0, 151.0], [48.1, 151.0], [48.2, 151.0], [48.3, 151.0], [48.4, 152.0], [48.5, 152.0], [48.6, 152.0], [48.7, 152.0], [48.8, 153.0], [48.9, 153.0], [49.0, 153.0], [49.1, 154.0], [49.2, 154.0], [49.3, 154.0], [49.4, 154.0], [49.5, 155.0], [49.6, 155.0], [49.7, 155.0], [49.8, 155.0], [49.9, 156.0], [50.0, 156.0], [50.1, 156.0], [50.2, 156.0], [50.3, 157.0], [50.4, 157.0], [50.5, 157.0], [50.6, 158.0], [50.7, 158.0], [50.8, 158.0], [50.9, 158.0], [51.0, 159.0], [51.1, 159.0], [51.2, 159.0], [51.3, 159.0], [51.4, 160.0], [51.5, 160.0], [51.6, 160.0], [51.7, 160.0], [51.8, 161.0], [51.9, 161.0], [52.0, 161.0], [52.1, 161.0], [52.2, 162.0], [52.3, 162.0], [52.4, 162.0], [52.5, 163.0], [52.6, 163.0], [52.7, 163.0], [52.8, 163.0], [52.9, 164.0], [53.0, 164.0], [53.1, 164.0], [53.2, 164.0], [53.3, 164.0], [53.4, 165.0], [53.5, 165.0], [53.6, 165.0], [53.7, 165.0], [53.8, 166.0], [53.9, 166.0], [54.0, 166.0], [54.1, 167.0], [54.2, 167.0], [54.3, 167.0], [54.4, 167.0], [54.5, 168.0], [54.6, 168.0], [54.7, 168.0], [54.8, 169.0], [54.9, 169.0], [55.0, 169.0], [55.1, 169.0], [55.2, 170.0], [55.3, 170.0], [55.4, 170.0], [55.5, 170.0], [55.6, 171.0], [55.7, 171.0], [55.8, 171.0], [55.9, 172.0], [56.0, 172.0], [56.1, 172.0], [56.2, 172.0], [56.3, 173.0], [56.4, 173.0], [56.5, 173.0], [56.6, 174.0], [56.7, 174.0], [56.8, 174.0], [56.9, 174.0], [57.0, 175.0], [57.1, 175.0], [57.2, 175.0], [57.3, 175.0], [57.4, 175.0], [57.5, 176.0], [57.6, 176.0], [57.7, 176.0], [57.8, 176.0], [57.9, 177.0], [58.0, 177.0], [58.1, 177.0], [58.2, 177.0], [58.3, 177.0], [58.4, 178.0], [58.5, 178.0], [58.6, 178.0], [58.7, 178.0], [58.8, 178.0], [58.9, 179.0], [59.0, 179.0], [59.1, 179.0], [59.2, 179.0], [59.3, 180.0], [59.4, 180.0], [59.5, 180.0], [59.6, 180.0], [59.7, 181.0], [59.8, 181.0], [59.9, 181.0], [60.0, 181.0], [60.1, 182.0], [60.2, 182.0], [60.3, 182.0], [60.4, 182.0], [60.5, 183.0], [60.6, 183.0], [60.7, 183.0], [60.8, 183.0], [60.9, 183.0], [61.0, 184.0], [61.1, 184.0], [61.2, 184.0], [61.3, 184.0], [61.4, 184.0], [61.5, 185.0], [61.6, 185.0], [61.7, 185.0], [61.8, 185.0], [61.9, 186.0], [62.0, 186.0], [62.1, 186.0], [62.2, 186.0], [62.3, 186.0], [62.4, 187.0], [62.5, 187.0], [62.6, 187.0], [62.7, 187.0], [62.8, 188.0], [62.9, 188.0], [63.0, 188.0], [63.1, 188.0], [63.2, 189.0], [63.3, 189.0], [63.4, 189.0], [63.5, 190.0], [63.6, 190.0], [63.7, 190.0], [63.8, 190.0], [63.9, 190.0], [64.0, 190.0], [64.1, 191.0], [64.2, 191.0], [64.3, 191.0], [64.4, 191.0], [64.5, 192.0], [64.6, 192.0], [64.7, 192.0], [64.8, 192.0], [64.9, 192.0], [65.0, 193.0], [65.1, 193.0], [65.2, 193.0], [65.3, 193.0], [65.4, 193.0], [65.5, 194.0], [65.6, 194.0], [65.7, 194.0], [65.8, 194.0], [65.9, 194.0], [66.0, 195.0], [66.1, 195.0], [66.2, 195.0], [66.3, 195.0], [66.4, 196.0], [66.5, 196.0], [66.6, 196.0], [66.7, 196.0], [66.8, 197.0], [66.9, 197.0], [67.0, 197.0], [67.1, 197.0], [67.2, 198.0], [67.3, 198.0], [67.4, 198.0], [67.5, 198.0], [67.6, 198.0], [67.7, 199.0], [67.8, 199.0], [67.9, 199.0], [68.0, 200.0], [68.1, 200.0], [68.2, 200.0], [68.3, 200.0], [68.4, 201.0], [68.5, 201.0], [68.6, 201.0], [68.7, 201.0], [68.8, 202.0], [68.9, 202.0], [69.0, 202.0], [69.1, 203.0], [69.2, 203.0], [69.3, 203.0], [69.4, 203.0], [69.5, 204.0], [69.6, 204.0], [69.7, 204.0], [69.8, 205.0], [69.9, 205.0], [70.0, 205.0], [70.1, 205.0], [70.2, 206.0], [70.3, 206.0], [70.4, 206.0], [70.5, 206.0], [70.6, 207.0], [70.7, 207.0], [70.8, 207.0], [70.9, 208.0], [71.0, 208.0], [71.1, 208.0], [71.2, 209.0], [71.3, 209.0], [71.4, 209.0], [71.5, 210.0], [71.6, 210.0], [71.7, 210.0], [71.8, 211.0], [71.9, 211.0], [72.0, 211.0], [72.1, 211.0], [72.2, 212.0], [72.3, 212.0], [72.4, 212.0], [72.5, 213.0], [72.6, 213.0], [72.7, 213.0], [72.8, 213.0], [72.9, 214.0], [73.0, 214.0], [73.1, 214.0], [73.2, 215.0], [73.3, 215.0], [73.4, 215.0], [73.5, 215.0], [73.6, 216.0], [73.7, 216.0], [73.8, 216.0], [73.9, 217.0], [74.0, 217.0], [74.1, 217.0], [74.2, 217.0], [74.3, 218.0], [74.4, 218.0], [74.5, 218.0], [74.6, 218.0], [74.7, 219.0], [74.8, 219.0], [74.9, 219.0], [75.0, 220.0], [75.1, 220.0], [75.2, 220.0], [75.3, 220.0], [75.4, 221.0], [75.5, 221.0], [75.6, 221.0], [75.7, 222.0], [75.8, 222.0], [75.9, 222.0], [76.0, 222.0], [76.1, 222.0], [76.2, 223.0], [76.3, 223.0], [76.4, 223.0], [76.5, 224.0], [76.6, 224.0], [76.7, 224.0], [76.8, 225.0], [76.9, 225.0], [77.0, 225.0], [77.1, 226.0], [77.2, 226.0], [77.3, 226.0], [77.4, 226.0], [77.5, 227.0], [77.6, 227.0], [77.7, 227.0], [77.8, 228.0], [77.9, 228.0], [78.0, 228.0], [78.1, 228.0], [78.2, 229.0], [78.3, 229.0], [78.4, 229.0], [78.5, 230.0], [78.6, 230.0], [78.7, 230.0], [78.8, 230.0], [78.9, 231.0], [79.0, 231.0], [79.1, 231.0], [79.2, 232.0], [79.3, 232.0], [79.4, 232.0], [79.5, 233.0], [79.6, 233.0], [79.7, 234.0], [79.8, 234.0], [79.9, 234.0], [80.0, 234.0], [80.1, 235.0], [80.2, 235.0], [80.3, 236.0], [80.4, 236.0], [80.5, 237.0], [80.6, 237.0], [80.7, 237.0], [80.8, 238.0], [80.9, 238.0], [81.0, 238.0], [81.1, 238.0], [81.2, 239.0], [81.3, 239.0], [81.4, 239.0], [81.5, 240.0], [81.6, 240.0], [81.7, 240.0], [81.8, 241.0], [81.9, 241.0], [82.0, 242.0], [82.1, 242.0], [82.2, 243.0], [82.3, 243.0], [82.4, 243.0], [82.5, 244.0], [82.6, 244.0], [82.7, 244.0], [82.8, 245.0], [82.9, 245.0], [83.0, 246.0], [83.1, 246.0], [83.2, 246.0], [83.3, 247.0], [83.4, 247.0], [83.5, 248.0], [83.6, 248.0], [83.7, 248.0], [83.8, 249.0], [83.9, 249.0], [84.0, 250.0], [84.1, 250.0], [84.2, 250.0], [84.3, 251.0], [84.4, 251.0], [84.5, 251.0], [84.6, 252.0], [84.7, 252.0], [84.8, 252.0], [84.9, 253.0], [85.0, 253.0], [85.1, 253.0], [85.2, 254.0], [85.3, 254.0], [85.4, 254.0], [85.5, 255.0], [85.6, 255.0], [85.7, 256.0], [85.8, 256.0], [85.9, 256.0], [86.0, 257.0], [86.1, 257.0], [86.2, 257.0], [86.3, 258.0], [86.4, 258.0], [86.5, 259.0], [86.6, 259.0], [86.7, 259.0], [86.8, 260.0], [86.9, 260.0], [87.0, 261.0], [87.1, 261.0], [87.2, 262.0], [87.3, 262.0], [87.4, 262.0], [87.5, 263.0], [87.6, 263.0], [87.7, 264.0], [87.8, 264.0], [87.9, 265.0], [88.0, 265.0], [88.1, 265.0], [88.2, 266.0], [88.3, 266.0], [88.4, 267.0], [88.5, 267.0], [88.6, 268.0], [88.7, 268.0], [88.8, 268.0], [88.9, 269.0], [89.0, 269.0], [89.1, 270.0], [89.2, 270.0], [89.3, 271.0], [89.4, 271.0], [89.5, 272.0], [89.6, 273.0], [89.7, 274.0], [89.8, 274.0], [89.9, 275.0], [90.0, 276.0], [90.1, 276.0], [90.2, 277.0], [90.3, 277.0], [90.4, 277.0], [90.5, 278.0], [90.6, 279.0], [90.7, 279.0], [90.8, 280.0], [90.9, 280.0], [91.0, 281.0], [91.1, 282.0], [91.2, 282.0], [91.3, 283.0], [91.4, 284.0], [91.5, 284.0], [91.6, 285.0], [91.7, 286.0], [91.8, 286.0], [91.9, 287.0], [92.0, 288.0], [92.1, 288.0], [92.2, 289.0], [92.3, 289.0], [92.4, 290.0], [92.5, 290.0], [92.6, 291.0], [92.7, 292.0], [92.8, 293.0], [92.9, 293.0], [93.0, 294.0], [93.1, 295.0], [93.2, 295.0], [93.3, 296.0], [93.4, 297.0], [93.5, 298.0], [93.6, 298.0], [93.7, 299.0], [93.8, 300.0], [93.9, 301.0], [94.0, 302.0], [94.1, 303.0], [94.2, 303.0], [94.3, 305.0], [94.4, 306.0], [94.5, 307.0], [94.6, 308.0], [94.7, 308.0], [94.8, 309.0], [94.9, 310.0], [95.0, 310.0], [95.1, 312.0], [95.2, 313.0], [95.3, 314.0], [95.4, 315.0], [95.5, 316.0], [95.6, 317.0], [95.7, 319.0], [95.8, 320.0], [95.9, 321.0], [96.0, 322.0], [96.1, 324.0], [96.2, 326.0], [96.3, 327.0], [96.4, 328.0], [96.5, 329.0], [96.6, 331.0], [96.7, 332.0], [96.8, 334.0], [96.9, 336.0], [97.0, 337.0], [97.1, 339.0], [97.2, 342.0], [97.3, 343.0], [97.4, 345.0], [97.5, 348.0], [97.6, 350.0], [97.7, 352.0], [97.8, 353.0], [97.9, 355.0], [98.0, 358.0], [98.1, 360.0], [98.2, 363.0], [98.3, 365.0], [98.4, 368.0], [98.5, 371.0], [98.6, 374.0], [98.7, 376.0], [98.8, 379.0], [98.9, 384.0], [99.0, 387.0], [99.1, 389.0], [99.2, 393.0], [99.3, 399.0], [99.4, 403.0], [99.5, 408.0], [99.6, 416.0], [99.7, 429.0], [99.8, 463.0], [99.9, 485.0], [100.0, 598.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 9.0, "minX": 0.0, "maxY": 3981.0, "series": [{"data": [[0.0, 2817.0], [300.0, 561.0], [100.0, 3981.0], [200.0, 2572.0], [400.0, 60.0], [500.0, 9.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 9.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 9991.0, "series": [{"data": [[0.0, 9991.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 9.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 1.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 23.804379562043806, "minX": 1.792732077E12, "maxY": 182.4061696658099, "series": [{"data": [[1.792732089E12, 62.80160857908846], [1.792732088E12, 106.99023199023189], [1.792732087E12, 133.05819477434676], [1.792732086E12, 154.6802884615386], [1.79273208E12, 126.90081521739127], [1.792732079E12, 90.51511169513797], [1.792732078E12, 60.310301507537666], [1.792732077E12, 23.804379562043806], [1.792732085E12, 162.2255154639174], [1.792732084E12, 167.76500638569627], [1.792732083E12, 175.71932299012698], [1.792732082E12, 182.4061696658099], [1.792732081E12, 163.6255088195387]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732089E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 6.5, "minX": 1.0, "maxY": 276.46153846153845, "series": [{"data": [[2.0, 9.0], [3.0, 13.5], [4.0, 12.0], [6.0, 12.0], [7.0, 22.666666666666668], [8.0, 10.549999999999999], [9.0, 12.000000000000004], [10.0, 15.384615384615383], [11.0, 13.708333333333334], [12.0, 13.944444444444446], [13.0, 14.967741935483868], [14.0, 18.176470588235297], [15.0, 16.10344827586207], [16.0, 18.458333333333332], [17.0, 26.35294117647059], [18.0, 21.749999999999996], [19.0, 22.576923076923077], [20.0, 21.826086956521735], [21.0, 29.583333333333336], [22.0, 24.26923076923077], [23.0, 29.68181818181818], [24.0, 27.520000000000003], [25.0, 30.80952380952381], [26.0, 29.809523809523814], [27.0, 33.931034482758626], [28.0, 33.35483870967742], [29.0, 33.65384615384615], [30.0, 37.80769230769231], [31.0, 34.2608695652174], [32.0, 36.6], [33.0, 35.77142857142857], [34.0, 39.86363636363635], [35.0, 41.44827586206897], [36.0, 47.421052631578945], [37.0, 46.74999999999999], [38.0, 52.892857142857146], [39.0, 49.642857142857146], [40.0, 58.25], [41.0, 53.65], [42.0, 58.11764705882353], [43.0, 50.823529411764696], [44.0, 62.65624999999999], [45.0, 52.285714285714285], [46.0, 51.5], [47.0, 57.115384615384606], [48.0, 57.689655172413794], [49.0, 69.3658536585366], [50.0, 53.969696969696976], [51.0, 65.6923076923077], [52.0, 61.235294117647065], [53.0, 66.95000000000002], [54.0, 60.208333333333336], [55.0, 66.42857142857142], [56.0, 63.47826086956522], [57.0, 71.53658536585364], [58.0, 67.27777777777777], [59.0, 81.88], [60.0, 94.375], [61.0, 83.48571428571427], [62.0, 72.1], [63.0, 70.04545454545453], [64.0, 77.00000000000004], [65.0, 82.58181818181815], [66.0, 72.38636363636364], [67.0, 70.0], [68.0, 84.52000000000001], [69.0, 80.98113207547172], [70.0, 75.52272727272728], [71.0, 76.0], [72.0, 84.09677419354838], [73.0, 84.79310344827587], [74.0, 76.96296296296296], [75.0, 91.08536585365853], [76.0, 90.90322580645164], [77.0, 90.8452380952381], [78.0, 80.26666666666667], [79.0, 83.7708333333333], [80.0, 96.4516129032258], [81.0, 104.29166666666669], [82.0, 84.85714285714285], [83.0, 112.85714285714286], [84.0, 104.9111111111111], [85.0, 106.23456790123456], [86.0, 99.50793650793648], [87.0, 93.33333333333333], [88.0, 99.24489795918369], [89.0, 116.54285714285714], [90.0, 100.2727272727273], [91.0, 114.4832214765101], [92.0, 108.0909090909091], [93.0, 111.68421052631578], [94.0, 115.80392156862749], [95.0, 116.59459459459458], [96.0, 120.36842105263158], [97.0, 104.02040816326532], [98.0, 116.18181818181819], [99.0, 111.80357142857144], [100.0, 113.98591549295773], [101.0, 125.74509803921572], [102.0, 100.05], [103.0, 151.65517241379308], [104.0, 125.74509803921569], [105.0, 139.98529411764704], [106.0, 111.35714285714285], [107.0, 163.60606060606057], [108.0, 171.1142857142857], [109.0, 151.2], [110.0, 144.99999999999997], [111.0, 148.4186046511628], [112.0, 164.47222222222226], [113.0, 130.4893617021277], [114.0, 133.375], [115.0, 138.8775510204082], [116.0, 130.6315789473684], [117.0, 140.07999999999996], [118.0, 172.69306930693074], [119.0, 169.2051282051282], [120.0, 143.54761904761907], [121.0, 148.95833333333331], [122.0, 152.13888888888886], [123.0, 156.83870967741933], [124.0, 142.92753623188403], [125.0, 164.66666666666666], [126.0, 147.6774193548387], [127.0, 145.58571428571432], [128.0, 171.38202247191006], [129.0, 158.8324022346368], [130.0, 173.8571428571429], [131.0, 177.35245901639345], [132.0, 165.62400000000008], [133.0, 174.35], [134.0, 156.55555555555551], [135.0, 157.92592592592595], [136.0, 161.84615384615387], [137.0, 177.37037037037038], [138.0, 183.20000000000002], [139.0, 171.32432432432435], [140.0, 169.71428571428575], [141.0, 161.875], [142.0, 124.75000000000003], [143.0, 174.59259259259258], [144.0, 168.77083333333337], [145.0, 175.2112676056338], [146.0, 181.23333333333338], [147.0, 204.78378378378378], [148.0, 186.97500000000005], [149.0, 180.82608695652175], [150.0, 193.70833333333334], [151.0, 178.65], [152.0, 168.66666666666666], [153.0, 182.99999999999994], [154.0, 202.5496183206106], [155.0, 181.6046511627907], [156.0, 187.86742424242436], [157.0, 197.72891566265062], [158.0, 212.0933333333333], [159.0, 222.23863636363637], [160.0, 216.86813186813197], [161.0, 235.82584269662925], [162.0, 194.45736434108517], [163.0, 210.7678571428571], [164.0, 198.22009569377985], [165.0, 206.67261904761904], [166.0, 213.65], [167.0, 194.69354838709688], [168.0, 221.85887096774198], [169.0, 222.38888888888889], [170.0, 237.77419354838707], [172.0, 258.66412213740455], [173.0, 265.85294117647067], [174.0, 252.18181818181816], [175.0, 219.99999999999994], [171.0, 276.46153846153845], [176.0, 230.1976744186047], [177.0, 234.48507462686564], [178.0, 234.990099009901], [179.0, 247.1164021164021], [180.0, 246.85106382978725], [181.0, 256.3076923076922], [182.0, 267.9130434782609], [183.0, 238.61443932411677], [1.0, 6.5]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[124.6132999999999, 159.7264999999998]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 183.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 258788.0, "minX": 1.792732077E12, "maxY": 380483.0, "series": [{"data": [[1.792732089E12, 337012.0], [1.792732088E12, 370032.0], [1.792732087E12, 380483.0], [1.792732086E12, 375904.0], [1.79273208E12, 332531.0], [1.792732079E12, 343796.0], [1.792732078E12, 359751.0], [1.792732077E12, 309478.0], [1.792732085E12, 350599.0], [1.792732084E12, 353830.0], [1.792732083E12, 320244.0], [1.792732082E12, 351432.0], [1.792732081E12, 332911.0]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.792732089E12, 281808.0], [1.792732088E12, 309426.0], [1.792732087E12, 318175.0], [1.792732086E12, 314336.0], [1.79273208E12, 278067.0], [1.792732079E12, 287482.0], [1.792732078E12, 300847.0], [1.792732077E12, 258788.0], [1.792732085E12, 293175.0], [1.792732084E12, 295888.0], [1.792732083E12, 267778.0], [1.792732082E12, 293860.0], [1.792732081E12, 278373.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732089E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 27.991240875912414, "minX": 1.792732077E12, "maxY": 244.40479548660085, "series": [{"data": [[1.792732089E12, 77.27077747989276], [1.792732088E12, 135.93528693528688], [1.792732087E12, 162.0368171021377], [1.792732086E12, 192.56370192307674], [1.79273208E12, 160.80298913043472], [1.792732079E12, 114.87779237844937], [1.792732078E12, 71.1746231155779], [1.792732077E12, 27.991240875912414], [1.792732085E12, 211.4342783505155], [1.792732084E12, 220.8454661558109], [1.792732083E12, 244.40479548660085], [1.792732082E12, 237.01928020565566], [1.792732081E12, 210.80189959294435]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732089E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 27.93576642335767, "minX": 1.792732077E12, "maxY": 244.39774330042297, "series": [{"data": [[1.792732089E12, 77.26943699731909], [1.792732088E12, 135.93284493284472], [1.792732087E12, 162.02969121140148], [1.792732086E12, 192.5588942307693], [1.79273208E12, 160.7948369565217], [1.792732079E12, 114.87779237844937], [1.792732078E12, 71.16582914572861], [1.792732077E12, 27.93576642335767], [1.792732085E12, 211.42912371134017], [1.792732084E12, 220.8429118773945], [1.792732083E12, 244.39774330042297], [1.792732082E12, 237.01799485861198], [1.792732081E12, 210.8005427408412]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732089E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.0, "minX": 1.792732077E12, "maxY": 0.20291970802919757, "series": [{"data": [[1.792732089E12, 0.0], [1.792732088E12, 0.0], [1.792732087E12, 0.0], [1.792732086E12, 0.0], [1.79273208E12, 0.04211956521739132], [1.792732079E12, 0.02233902759526939], [1.792732078E12, 0.027638190954773906], [1.792732077E12, 0.20291970802919757], [1.792732085E12, 0.0], [1.792732084E12, 0.0], [1.792732083E12, 0.0], [1.792732082E12, 0.007712082262210797], [1.792732081E12, 0.020352781546811406]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732089E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 5.0, "minX": 1.792732077E12, "maxY": 598.0, "series": [{"data": [[1.792732089E12, 244.0], [1.792732088E12, 290.0], [1.792732087E12, 370.0], [1.792732086E12, 425.0], [1.79273208E12, 422.0], [1.792732079E12, 340.0], [1.792732078E12, 194.0], [1.792732077E12, 141.0], [1.792732085E12, 569.0], [1.792732084E12, 506.0], [1.792732083E12, 598.0], [1.792732082E12, 537.0], [1.792732081E12, 471.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.792732089E12, 5.0], [1.792732088E12, 10.0], [1.792732087E12, 8.0], [1.792732086E12, 10.0], [1.79273208E12, 12.0], [1.792732079E12, 9.0], [1.792732078E12, 9.0], [1.792732077E12, 6.0], [1.792732085E12, 10.0], [1.792732084E12, 13.0], [1.792732083E12, 9.0], [1.792732082E12, 57.0], [1.792732081E12, 13.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.792732089E12, 128.0], [1.792732088E12, 204.0], [1.792732087E12, 233.0], [1.792732086E12, 281.70000000000005], [1.79273208E12, 223.30000000000007], [1.792732079E12, 177.0], [1.792732078E12, 109.0], [1.792732077E12, 51.39999999999998], [1.792732085E12, 332.0], [1.792732084E12, 317.20000000000005], [1.792732083E12, 344.0], [1.792732082E12, 315.1], [1.792732081E12, 294.20000000000005]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.792732089E12, 178.52999999999997], [1.792732088E12, 259.1999999999998], [1.792732087E12, 300.0], [1.792732086E12, 353.0099999999999], [1.79273208E12, 295.52], [1.792732079E12, 245.38], [1.792732078E12, 157.02999999999997], [1.792732077E12, 91.41999999999996], [1.792732085E12, 468.9200000000001], [1.792732084E12, 405.31999999999994], [1.792732083E12, 427.6999999999997], [1.792732082E12, 407.6300000000001], [1.792732081E12, 390.72]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.792732089E12, 74.5], [1.792732088E12, 132.0], [1.792732087E12, 160.0], [1.792732086E12, 192.0], [1.79273208E12, 160.0], [1.792732079E12, 114.0], [1.792732078E12, 68.0], [1.792732077E12, 24.0], [1.792732085E12, 204.0], [1.792732084E12, 221.0], [1.792732083E12, 243.0], [1.792732082E12, 234.5], [1.792732081E12, 206.0]], "isOverall": false, "label": "Median", "isController": false}, {"data": [[1.792732089E12, 148.0], [1.792732088E12, 224.0], [1.792732087E12, 257.0], [1.792732086E12, 308.0], [1.79273208E12, 246.0], [1.792732079E12, 197.79999999999995], [1.792732078E12, 122.0], [1.792732077E12, 61.0], [1.792732085E12, 384.44999999999993], [1.792732084E12, 352.0], [1.792732083E12, 373.5], [1.792732082E12, 346.0], [1.792732081E12, 328.20000000000005]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732089E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 24.0, "minX": 685.0, "maxY": 243.0, "series": [{"data": [[685.0, 24.0], [709.0, 243.0], [761.0, 114.0], [736.0, 160.0], [737.0, 206.0], [746.0, 74.5], [796.0, 68.0], [778.0, 234.5], [783.0, 221.0], [776.0, 204.0], [819.0, 132.0], [832.0, 192.0], [842.0, 160.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 842.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 24.0, "minX": 685.0, "maxY": 243.0, "series": [{"data": [[685.0, 24.0], [709.0, 243.0], [761.0, 114.0], [736.0, 160.0], [737.0, 206.0], [746.0, 74.5], [796.0, 68.0], [778.0, 234.5], [783.0, 221.0], [776.0, 204.0], [819.0, 132.0], [832.0, 192.0], [842.0, 160.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 842.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 655.0, "minX": 1.792732077E12, "maxY": 830.0, "series": [{"data": [[1.792732089E12, 655.0], [1.792732088E12, 786.0], [1.792732087E12, 817.0], [1.792732086E12, 822.0], [1.79273208E12, 775.0], [1.792732079E12, 793.0], [1.792732078E12, 830.0], [1.792732077E12, 726.0], [1.792732085E12, 770.0], [1.792732084E12, 776.0], [1.792732083E12, 702.0], [1.792732082E12, 774.0], [1.792732081E12, 774.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732089E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 685.0, "minX": 1.792732077E12, "maxY": 842.0, "series": [{"data": [[1.792732089E12, 746.0], [1.792732088E12, 819.0], [1.792732087E12, 842.0], [1.792732086E12, 832.0], [1.79273208E12, 736.0], [1.792732079E12, 761.0], [1.792732078E12, 796.0], [1.792732077E12, 685.0], [1.792732085E12, 776.0], [1.792732084E12, 783.0], [1.792732083E12, 709.0], [1.792732082E12, 778.0], [1.792732081E12, 737.0]], "isOverall": false, "label": "201", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 1.792732089E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 685.0, "minX": 1.792732077E12, "maxY": 842.0, "series": [{"data": [[1.792732089E12, 746.0], [1.792732088E12, 819.0], [1.792732087E12, 842.0], [1.792732086E12, 832.0], [1.79273208E12, 736.0], [1.792732079E12, 761.0], [1.792732078E12, 796.0], [1.792732077E12, 685.0], [1.792732085E12, 776.0], [1.792732084E12, 783.0], [1.792732083E12, 709.0], [1.792732082E12, 778.0], [1.792732081E12, 737.0]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732089E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 685.0, "minX": 1.792732077E12, "maxY": 842.0, "series": [{"data": [[1.792732089E12, 746.0], [1.792732088E12, 819.0], [1.792732087E12, 842.0], [1.792732086E12, 832.0], [1.79273208E12, 736.0], [1.792732079E12, 761.0], [1.792732078E12, 796.0], [1.792732077E12, 685.0], [1.792732085E12, 776.0], [1.792732084E12, 783.0], [1.792732083E12, 709.0], [1.792732082E12, 778.0], [1.792732081E12, 737.0]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 1000, "maxX": 1.792732089E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 28800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

